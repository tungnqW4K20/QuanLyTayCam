﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace WebApplicationADMIN.Models
{
    public class ChiTietHoaDonNhapViewModel
    {
        [Required]
        [Display(Name = "Sản Phẩm")]
        public int MaSanPham { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập số lượng.")]
        [Range(1, int.MaxValue, ErrorMessage = "Số lượng phải lớn hơn 0.")]
        [Display(Name = "Số Lượng")]
        public int SoLuongNhap { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập giá nhập.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Giá nhập phải lớn hơn 0.")]
        [DataType(DataType.Currency)] // Optional: helps with formatting/validation
        [Display(Name = "Giá Nhập")]
        public decimal GiaNhap { get; set; }
    }
}
