﻿namespace WebApplicationADMIN.Models
{
    public class GiaNhapModelADMIN
    {
        public int MaSanPham { get; set; }
        public decimal GiaNhap { get; set; }
    }
}
