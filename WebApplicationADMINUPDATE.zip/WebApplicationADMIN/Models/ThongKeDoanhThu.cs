﻿namespace WebApplicationADMIN.Models
{
    public class ThongKeDoanhThu
    {
        public int TongSanPham { get; set; }
        public int TongDH { get; set; }
        public decimal TongThuNhap { get; set; }

        public decimal TongNhapHang { get; set; }

        public decimal TongLai { get; set; }
        public int TongHetHang { get; set; }
        public int TongDHHuy { get; set; }

    }
}
