﻿namespace WebApplicationADMIN.Models
{
    public class HoaDonBanADMINModel
    {
        public int MaHoaDonBan { get; set; }
        public decimal TongTien { get; set; }
        public string TrangThai { get; set; }
        public string TenKhachHang { get; set; }

    }
}
