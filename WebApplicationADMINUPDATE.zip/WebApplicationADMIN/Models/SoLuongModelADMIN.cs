﻿namespace WebApplicationADMIN.Models
{
    public class SoLuongModelADMIN
    {
        public int MaSanPham { get; set; }
        public int SoLuong { get; set; }
    }
}
