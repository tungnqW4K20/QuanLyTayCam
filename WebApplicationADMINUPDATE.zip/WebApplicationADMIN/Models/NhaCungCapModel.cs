﻿namespace WebApplicationADMIN.Models
{
    public class NhaCungCapModel
    {
        public string MaNhaCungCap { get; set; }
        public string TenNhaCungCap { get; set; }

    }
}
