﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class HoaDonDatHangModel
    {

        public int MaHoaDon { get; set; }
        public string NgayDat { get; set; }

        public decimal TongTien { get; set; }

        public string TrangThai { get; set; }

    }
}
