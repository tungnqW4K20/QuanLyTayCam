﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class HoaDonNhapModel
    {
        public int MaHoaDonNhap { get; set; }
        public DateTime NgayNhap { get; set; }
        public string TrangThai { get; set; }

        public int MaNhaCungCap { get; set; }

    }
}
