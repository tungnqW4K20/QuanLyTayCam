﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ChiTietSPModelHetHang
    {
        public Nullable<int> MaSanPham { get; set; }
        public string NoiDungChiTiet { get; set; }
        public string Video { get; set; }
        public string Anh1 { get; set; }
        public string Anh2 { get; set; }
        public string Anh3 { get; set; }
        public string Anh4 { get; set; }
        public string CPU { get; set; }
        public string GPU { get; set; }
        public string RAM { get; set; }
        public string Storage { get; set; }
        public string HienThi { get; set; }
        public string TrongLuong { get; set; }
        public string KichThuoc { get; set; }
        public int HetHang { get; set; }
    }
}
