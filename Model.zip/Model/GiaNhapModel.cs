﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
	public class GiaNhapModel
	{
		public int MaSanPham { get; set; }
		public decimal GiaNhap { get; set; }
	}
}
