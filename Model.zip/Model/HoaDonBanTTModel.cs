﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class HoaDonBanTTModel
    {
        public int MaHoaDonBan { get; set; }
        public decimal TongTien { get; set; }
        public string TrangThai { get; set; }
        public string TenKhachHang { get; set; }

    }
}
