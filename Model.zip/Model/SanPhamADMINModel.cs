﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class SanPhamADMINModel
    {
        public int MaSanPham { get; set; }
        public string TenSanPham { get; set; }

        public int SoLuong { get; set; }
        public Nullable<decimal> Gia { get; set; }
        public string HinhAnh { get; set; }

        public string TinhTrang { get; set; }

        public string DanhMuc { get; set; }


    }



}
