﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
	public class GioHangModel
	{
		public int MaGH { get; set; }
		public int MaSanPham { get; set; }
		public int MaKhachHang { get; set; }
		public string TenSanPham { get; set; }
		public int SoLuongThem { get; set; }
		public decimal DonGia { get; set; }
		public string HinhAnh { get; set; }
		public decimal ThanhTien => DonGia * SoLuongThem;
	}
}
