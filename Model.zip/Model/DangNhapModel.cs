﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
	public class DangNhapModel
	{
		public int MaTK { get; set; }
		
		public string TenTK { get; set; }
		public string MK { get; set; }
		
		public int MaKhachHang { get; set; }
		
	}
}
