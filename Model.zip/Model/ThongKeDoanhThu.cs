﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ThongKeDoanhThu
    {
        public int TongSanPham { get; set; }
        public int TongDH { get; set; }
        public decimal TongThuNhap { get; set; }

        public decimal TongNhapHang { get; set; }

        public decimal TongLai { get; set; }
        public int TongHetHang { get; set; }
        public int TongDHHuy { get; set; }

    }
}
