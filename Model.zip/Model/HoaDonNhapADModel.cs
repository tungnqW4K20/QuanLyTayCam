﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class HoaDonNhapADModel
    {
        public int MaHoaDonNhap { get; set; }
        public DateTime NgayNhap { get; set; }
        public string TrangThai { get; set; }

        public string NhaCungCap { get; set; }

        public int MaChiTietHoaDonNhap { get; set; }

        public string TenSanPham { get; set; }
        public int SoLuongNhap { get; set; }

        public decimal GiaNhap { get; set; }
    }
}
