﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
	public class ThongTinHoaDonMoDel
	{

		public int MaSanPham { get; set; }
		public string UserNameKH { get; set; }

		public int SoLuongBan { get; set; }

		public decimal DonGiaBan { get; set; }

	}
}
