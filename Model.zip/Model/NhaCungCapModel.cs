﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class NhaCungCapModel
    {
        public int MaNhaCungCap { get; set; }
        
        public string TenNhaCungCap { get; set; }
        public string DiaChiNhaCungCap { get; set; }
      
        public string SDTNhaCungCap { get; set; }

        public string EmailNhaCungCap { get; set; }



    }
}
