﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
	public  class ChiTietHoaDonBanModel
	{
		public int MaChiTietHoaDon { get; set; }
		public int MaHoaDonBan { get; set; }
		public int MaSanPham { get; set; }
		public int SoLuongBan { get; set; }
		public decimal DonGiaBan { get; set; }
	}
}
