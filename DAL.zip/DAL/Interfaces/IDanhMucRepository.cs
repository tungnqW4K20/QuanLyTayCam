﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
namespace DAL.Interfaces
{
    public partial interface IDanhMucRepository
    {
        bool Create(DanhMucModel model);
        bool Update(DanhMucModel model);
        bool Delete(DanhMucModel model);
        List<DanhMucModel> GetAll();
    }
}
