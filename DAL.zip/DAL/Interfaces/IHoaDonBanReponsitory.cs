﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace DAL.Interfaces
{
	public partial interface IHoaDonBanReponsitory
	{
		bool Create(HoaDonBanModel model);
		bool Update(HoaDonBanModel model);
		bool Delete(string id);
		List<HoaDonBanModel> GetAll();
		
		List<HoaDonBanModel> GetAllByID(int id);

        List<HoaDonDatHangModel> GetAllByIDtheoUser(string id);
        List<HoaDonKhachHangModel> GetAllHDMax();

        List<HoaDonBanTTModel> GetAllTT();


    }
}
