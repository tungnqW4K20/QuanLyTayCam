﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Interfaces
{
    public partial interface IChiTietSanPhamRepository
    {

        bool Create(ChiTietSanPhamModel model);
        bool Update(ChiTietSanPhamModel model);
        bool Delete(string id);

        List<ChiTietSanPhamModel1> GetAllByID(int id);
    }
}
