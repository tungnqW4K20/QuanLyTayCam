﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Interfaces
{
    public partial interface IChiTietHoaDonNhapADMINReponsitory
    {
        bool Create(HoaDonNhapADMINModel model);
        bool Update(HoaDonNhapADMINModel model);
        bool Delete(string id);
        List<HoaDonNhapADModel> GetAll();

        List<HoaDonNhapADMINModel> GetAllByID(int id);

        List<ThongKeDoanhThu> GetAllDT();


    }
}
