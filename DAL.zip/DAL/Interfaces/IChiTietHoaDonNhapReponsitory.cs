﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace DAL.Interfaces
{
    public partial interface IChiTietHoaDonNhapReponsitory
    {
        bool Create(ChiTietHoaDonNhapModel model);
        bool Update(ChiTietHoaDonNhapModel model);
        bool Delete(string id);
        List<ChiTietHoaDonNhapModel> GetAll();
        
        List<ChiTietHoaDonNhapModel> GetAllByID(int id);

        
       
    }
}
