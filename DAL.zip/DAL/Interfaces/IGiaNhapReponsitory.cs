﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Interfaces
{
	public partial interface IGiaNhapReponsitory
	{
		bool Create(GiaNhapModel model);
		bool Update(GiaNhapModel model);
		bool Delete(string id);
		List<GiaNhapModel> GetAll();
		
		List<GiaNhapModel> GetAllByID(int id);

	}
}
