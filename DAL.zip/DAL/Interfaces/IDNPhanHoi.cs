﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace DAL.Interfaces
{
	public partial interface IDNPhanHoi
	{
		bool Create(DangNhapModel model);
		bool Update(DangNhapModel model);
		bool Delete(string id);
		List<DangNhapModel> GetAll();
		List<DangNhapModel> GetAllTop();
		List<DangNhapModel> GetAllByID(int id);

	}
}
