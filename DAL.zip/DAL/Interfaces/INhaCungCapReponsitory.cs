﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;


namespace DAL.Interfaces
{
    public partial interface INhaCungCapReponsitory
    {

        bool Create(NhaCungCapModel model);
        bool Update(NhaCungCapModel model);
        bool Delete(string id);
        List<NhaCungCapModel> GetAll();
        List<NhaCungCapModel> GetAllByID(int id);
        List<NhaCungCapModel> GetAllByTenM(string id);


    }
}
