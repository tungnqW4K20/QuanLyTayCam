﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
namespace DAL.Interfaces
{
	public partial interface IKhachHangReponsitory
	{
		bool Create(KhachHangModel model);

		bool Update(KhachHangModel model);
        bool Updatetheouser(KhachHangModel2 model);

        bool Delete(string id);

		List<KhachHangModel> GetAll();
		List<KhachHangModel> GetAllByID(int id);
		List<KhachHangModel> GetAllByIDtheoUser(string id);

	}

}
