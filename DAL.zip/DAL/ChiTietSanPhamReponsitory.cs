﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public partial class ChiTietSanPhamRepository : IChiTietSanPhamRepository
    {
        private IDatabaseHelper _dbHelper;
        public ChiTietSanPhamRepository(IDatabaseHelper dbHelper)
        {
            _dbHelper = dbHelper;
        }

        public bool Create(ChiTietSanPhamModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiet_create",
				
				"@MaSanPham", model.MaSanPham,
				"@NoiDungChiTiet", model.NoiDungChiTiet,
				"@Video", model.Video,
				"@Anh1", model.Anh1,
				"@Anh2", model.Anh2,
				"@Anh3", model.Anh3,
				"@Anh4", model.Anh4,
				"@CPU", model.CPU,
				"@GPU", model.GPU,
				"@RAM", model.RAM,
				"@Storage", model.Storage,
				"@HienThi", model.HienThi,
				"@TrongLuong", model.TrongLuong,
				"@KichThuoc", model.KichThuoc);
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    throw new Exception(Convert.ToString(result) + msgError);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public bool Update(ChiTietSanPhamModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiet_update",
                
                "@MaSanPham", model.MaSanPham,
                "@NoiDungChiTiet",model.NoiDungChiTiet,
                "@Video",model.Video,
				"@Anh1", model.Anh1,
				"@Anh2", model.Anh2,
				"@Anh3", model.Anh3,
				"@Anh4", model.Anh4,
                "@CPU",model.CPU,
                "@GPU",model.GPU,
				"@RAM",model.RAM,
				"@Storage",model.Storage,
				"@HienThi",model.HienThi,
				"@TrongLuong",model.TrongLuong,
				"@KichThuoc",model.KichThuoc

				);
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    throw new Exception(Convert.ToString(result) + msgError);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



		public bool Delete(string id)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitietsanpham_delete",
				"@MaSanPham", id
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}



		public List<ChiTietSanPhamModel1> GetAllByID(int id)
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_chitietsanpham_getallbyid", "@MaSanPham", id);
			return dt.ConvertTo<ChiTietSanPhamModel1>().ToList();
		}


	}
}
