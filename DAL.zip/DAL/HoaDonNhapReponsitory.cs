﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DAL
{
    public partial class HoaDonNhapReponsitory : IHoaDonNhapReponsitory
    {
        private IDatabaseHelper _dbHelper;
        public HoaDonNhapReponsitory(IDatabaseHelper dbHelper)
        {
            _dbHelper = dbHelper;
        }

        public bool Create(HoaDonNhapModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_hoadonhap_create",
                    "@NgayNhap",model.NgayNhap,
                    "@TrangThai",model.TrangThai,
                    "@MaNhaCungCap",model.MaNhaCungCap
                   // cần sửa lại để gọi theo kiểu JSON      
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    throw new Exception(Convert.ToString(result));
                    // return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Update(HoaDonNhapModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_hoadonnhap_update",

                   "@MaHoaDonNhap",model.MaHoaDonNhap,
                   "@TrangThai",model.TrangThai
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public bool Delete(string id)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_hoadonnhap_delete",
                "@MaHoaDonNhap", id
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<HoaDonNhapModel> GetAll()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_hoadonnhap_getall");
            return dt.ConvertTo<HoaDonNhapModel>().ToList();

            //    return dt.Con
        }


        

        public List<HoaDonNhapModel> GetAllByID(int id)
        {


            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_hoadonnhap_getallbyid", "@MaHoaDonNhap", id);
            return dt.ConvertTo<HoaDonNhapModel>().ToList();


            //    return dt.Con
        }
    }
}




