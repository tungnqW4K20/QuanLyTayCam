﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
	public partial class LoginReponsitory : ILoginRepository
	{
		private IDatabaseHelper _dbHelper;
		public LoginReponsitory(IDatabaseHelper dbHelper)
		{
			_dbHelper = dbHelper;
		}

		public bool Loginstring(LoginModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_loginKH",
				"@UserName", model.UserName,
				"@Pass", model.MK
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
