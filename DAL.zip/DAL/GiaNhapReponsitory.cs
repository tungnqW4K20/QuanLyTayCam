﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
	public partial class GiaNhapReponsitory : IGiaNhapReponsitory
	{
		private IDatabaseHelper _dbHelper;
		public GiaNhapReponsitory(IDatabaseHelper dbHelper)
		{
			_dbHelper = dbHelper;
		}

		public bool Create(GiaNhapModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_gianhap_create",
				"@MaSanPham", model.MaSanPham,
				"@GiaNhap", model.GiaNhap
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					//   throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public bool Update(GiaNhapModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_gianhap_update",
					"@MaSanPham", model.MaSanPham,
				"@GiaNhap", model.GiaNhap
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}



		public bool Delete(string id)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_gianhap_delete",
				"@MaSanPham", id
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public List<GiaNhapModel> GetAll()
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_gianhap_getall");
			return dt.ConvertTo<GiaNhapModel>().ToList();

			//    return dt.Con
		}


		
		public List<GiaNhapModel> GetAllByID(int id)
		{

			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_gianhap_getallbyid", "@MaSanPham", id);
			return dt.ConvertTo<GiaNhapModel>().ToList();

			//    return dt.Con
		}

	}
}
