﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
	public partial class KhachHangReponsitory : IKhachHangReponsitory
	{
		private IDatabaseHelper _dbHelper;
		public KhachHangReponsitory(IDatabaseHelper dbHelper)
		{
			_dbHelper = dbHelper;
		}

		public bool Create(KhachHangModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_KhachHang_create",
				"@TenKH",model.TenKH,
				"@SDTKH",model.SDTKH,
				"@Email",model.Email,
				"@DiaChiKH",model.DiaChiKH);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					//   throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public bool Update(KhachHangModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_KhachHang_update",
				"@TenKH", model.TenKH,
				"@SDTKH", model.SDTKH,
				"@Email", model.Email,
				"@DiaChiKH", model.DiaChiKH,
                "@MaKH", model.MaKhachHang
                );
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public bool Updatetheouser(KhachHangModel2 model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_KhachHang_updatetheouser",
                    "@TenKH", model.TenKH,
                "@SDTKH", model.SDTKH,
                "@Email", model.Email,
                "@DiaChiKH", model.DiaChiKH,
                 "@MaKH", model.MaKhachHang
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        public bool Delete(string id)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_KhachHang_delete",
				"@MaKhachHang", id
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public List<KhachHangModel> GetAll()
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_KhachHang_getall");
			return dt.ConvertTo<KhachHangModel>().ToList();

			//    return dt.Con
		}


		public List<KhachHangModel> GetAllTop()//chưa làm storage
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_KhachHang_getalltop");//tìm khách hàng mua nhiều đồ nhất
			return dt.ConvertTo<KhachHangModel>().ToList();
			//    return dt.Con
		}



		public List<KhachHangModel> GetAllByID(int id)
		{

			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_KhachHang_getallbyid", "@MaKhachHang", id);
			return dt.ConvertTo<KhachHangModel>().ToList();

			//    return dt.Con
		}

		public List<KhachHangModel> GetAllByIDtheoUser(string id)
		{

			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_KhachHang_getallbyidtheouser", "@username", id);
			return dt.ConvertTo<KhachHangModel>().ToList();

			//    return dt.Con
		}




	}
}
