﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DAL
{
    public partial class NhaCungCapReponsitory : INhaCungCapReponsitory
    {
        private IDatabaseHelper _dbHelper;
        public NhaCungCapReponsitory(IDatabaseHelper dbHelper)
        {
            _dbHelper = dbHelper;
        }

        public bool Create(NhaCungCapModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_nhacungcap_create",
                    "@TenNhaCungCap",model.TenNhaCungCap,
                    "@DiaChiNhaCungCap", model.DiaChiNhaCungCap,
                    "@SDTNhaCungCap",model.SDTNhaCungCap,
                    "@EmailNhaCungCap",model.EmailNhaCungCap
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                   // throw new Exception(Convert.ToString(result));
                     return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Update(NhaCungCapModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_nhacungcap_update",
                    "@MaNhaCungCap",model.MaNhaCungCap,
                    "@TenNhaCungCap",model.TenNhaCungCap,
                    "@DiaChiNhaCungCap",model.DiaChiNhaCungCap,
                    "@SDTNhaCungCap",model.SDTNhaCungCap,
                    "@EmailNhaCungCap",model.EmailNhaCungCap
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public bool Delete(string id)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_nhacungcap_delete",
                "@MaNhaCungCap", id
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<NhaCungCapModel> GetAll()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_nhacungcap_getall");
            return dt.ConvertTo<NhaCungCapModel>().ToList();

            //    return dt.Con
        }

        public List<NhaCungCapModel> GetAllByID(int id)
        {


            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_nhacungcap_getallbyid", "@MaNhaCungCap", id);
            return dt.ConvertTo<NhaCungCapModel>().ToList();


            //    return dt.Con
        }

        public List<NhaCungCapModel> GetAllByTenM(string id)
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_nhacungcap_getallbyname", "@TenNhaCungCap", id);
            return dt.ConvertTo<NhaCungCapModel>().ToList();
            //    return dt.Con
        }
    }
}




