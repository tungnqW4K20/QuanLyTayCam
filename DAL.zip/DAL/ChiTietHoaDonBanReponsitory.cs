﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DAL
{
	public partial class ChiTietHoaDonBanReponsitory : IChiTietHoaDonBanReponsitory
	{
		private IDatabaseHelper _dbHelper;
		public ChiTietHoaDonBanReponsitory(IDatabaseHelper dbHelper)
		{
			_dbHelper = dbHelper;
		}

		public bool Create(ChiTietHoaDonBanModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiethoadonban_create",
                    "@MaHoaDonBan", model.MaHoaDonBan,
                    "@MaSanPham", model.MaSanPham
                );
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					throw new Exception(Convert.ToString(result));
					// return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public bool Update(ChiTietHoaDonBanModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiethoadonban_update",
                    "@MaHoaDonBan", model.MaHoaDonBan,
                    "@MaSanPham", model.MaSanPham
                );
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}



		public bool Delete(string id)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiethoadonban_delete",
				"@MaChiTietHoaDonBan", id
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public List<ChiTietHoaDonBanModel> GetAll()
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_chitiethoadonban_getall");
			return dt.ConvertTo<ChiTietHoaDonBanModel>().ToList();

			//    return dt.Con
		}


		

		public List<ChiTietHoaDonBanModel> GetAllByID(int id)
		{


			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_chitiethoadonban_getallbyid", "@MaChiTietHoaDonBan", id);
			return dt.ConvertTo<ChiTietHoaDonBanModel>().ToList();


			//    return dt.Con
		}

        public List<CHiTietHDBanKHModel> GetAllByIDTheoMaHD(int id)
        {


            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_chitiethoadonban_getallbyidmahd", "@MaHoaDonBan", id);
            return dt.ConvertTo<CHiTietHDBanKHModel>().ToList();


            //    return dt.Con
        }


        public bool  ThemHoaDon(List<ThongTinHoaDonMoDel> model)
		{

			string HDXML = "<Root>";
			foreach(var item in model)
			{
				HDXML  += " <SDT MaSanPham = \"" + item.MaSanPham.ToString()
					+ "\" MaKhachHang = \"" + item.UserNameKH.ToString()
						+ "\" SoLuongBan = \"" + item.SoLuongBan.ToString()
						+ "\" DonGiaBan = \"" + item.DonGiaBan.ToString()
						+ "\"/>";

			}
			HDXML += "</Root>";

			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_themhoadonkh",
					"@HoaDonXML", HDXML
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}



	}
}
