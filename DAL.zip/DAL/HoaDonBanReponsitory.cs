﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DAL
{
	public partial class HoaDonBanReponsitory : IHoaDonBanReponsitory
	{
		private IDatabaseHelper _dbHelper;
		public HoaDonBanReponsitory(IDatabaseHelper dbHelper)
		{
			_dbHelper = dbHelper;
		}

		public bool Create(HoaDonBanModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_hoadon_create",
					"@@MaKhachHang",model.MaKhachHang,
					"@NgayBan",model.NgayBan,
					"@TrangThai",model.TrangThai
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					throw new Exception(Convert.ToString(result));
					// return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public bool Update(HoaDonBanModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_hoadonban_update",
					"@MaHoaDonBan",model.MaHoaDonBan,
					"@TrangThai",model.TrangThai
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}



		public bool Delete(string id)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_hoadon_delete",
				"@MaHoaDonBan", id
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public List<HoaDonBanModel> GetAll()
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_hoadonban_getall");
			return dt.ConvertTo<HoaDonBanModel>().ToList();

			//    return dt.Con
		}


		public List<HoaDonKhachHangModel> GetAllHDMax()
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_hoadonban_getmax");
			return dt.ConvertTo<HoaDonKhachHangModel>().ToList();

			//    return dt.Con
		}

		public List<HoaDonBanModel> GetAllByID(int id)
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_hoadonban_getallbyid", "@MaHoaDonBan", id);
			return dt.ConvertTo<HoaDonBanModel>().ToList();
			//    return dt.Con
		}
        public List<HoaDonDatHangModel> GetAllByIDtheoUser(string id)
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_hoadonban_getallbyiduser", "@Username", id);
            return dt.ConvertTo<HoaDonDatHangModel>().ToList();
            //    return dt.Con
        }
        public List<HoaDonBanTTModel> GetAllTT()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_hoadonban_getalltt");
            return dt.ConvertTo<HoaDonBanTTModel>().ToList();

            //    return dt.Con
        }

    }
}
