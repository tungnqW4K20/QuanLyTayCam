﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
	public partial class DNPH : IDNPhanHoi
	{
		private IDatabaseHelper _dbHelper;
		public DNPH(IDatabaseHelper dbHelper)
		{
			_dbHelper = dbHelper;
		}

		public bool Create(DangNhapModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_dangnhap_create",
				"@MaTaiKhoan", model.MaTK,
				"@TenTK",model.TenTK,
				"@MK",model.MK,
				"@MaKH",model.MaKhachHang
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					//   throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public bool Update(DangNhapModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_dangnhap_update", "@MaTaiKhoan", model.MaTK,
				"@TenTK", model.TenTK,
				"@MK", model.MK,
				"@MaKH", model.MaKhachHang

				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}



		public bool Delete(string id)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_dangnhap_delete",
				"@MaTK", id
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public List<DangNhapModel> GetAll()
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_sanpham_getall");
			return dt.ConvertTo<DangNhapModel>().ToList();

			//    return dt.Con
		}


		public List<DangNhapModel> GetAllTop()
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_dangnhap_getalltop");
			return dt.ConvertTo<DangNhapModel>().ToList();

			//    return dt.Con
		}

		public List<DangNhapModel> GetAllByID(int id)
		{

			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_dangnhap_getallbyid", "@MaTK", id);
			return dt.ConvertTo<DangNhapModel>().ToList();

			//    return dt.Con
		}




	}
}
