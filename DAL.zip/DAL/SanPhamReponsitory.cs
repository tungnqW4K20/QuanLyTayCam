﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DAL
{
    public partial class SanPhamRepository : ISanPhamRepository
	{
        private IDatabaseHelper _dbHelper;
        public SanPhamRepository(IDatabaseHelper dbHelper)
        {
            _dbHelper = dbHelper;
        }
     
        public bool Create(SanPhamModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_sanpham_create",
                "@MaDanhMuc", model.MaDanhMuc,
                "@MaSanPham", model.MaSanPham,
                "@TenSanPham", model.TenSanPham,
                "@NoiDung", model.NoiDung,
                "@Gia", model.Gia,
                "@HinhAnh", model.HinhAnh,
                "@SanPhamTop", model.SanPhamTop,
                "@SanPhamUuDai", model.SanPhamUuDai);
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    throw new Exception(Convert.ToString(result) );
                  // return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Update(SanPhamModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_sanpham_update",
                    "@MaDanhMuc", model.MaDanhMuc,
                "@MaSanPham", model.MaSanPham,
                "@TenSanPham", model.TenSanPham,
                "@NoiDung", model.NoiDung,
                "@Gia", model.Gia,
                "@HinhAnh", model.HinhAnh,
                "@SanPhamTop", model.SanPhamTop,
                "@SanPhamUuDai", model.SanPhamUuDai
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public bool Delete( string id)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_sanpham_delete",
                "@MaSanPham", id
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<SanPhamModel> GetAll()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable( out msgError, "sp_sanpham_getall");
            return dt.ConvertTo<SanPhamModel>().ToList();

        //    return dt.Con
        }


        public List<SanPhamADMINModel> GetAllADMIN()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_sanpham_getalladmin");
            return dt.ConvertTo<SanPhamADMINModel>().ToList();

            //    return dt.Con
        }

        public List<SanPhamADMINModel> GetAllADMINHetHang()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_sanpham_getalladminhethang");
            return dt.ConvertTo<SanPhamADMINModel>().ToList();

            //    return dt.Con
        }

        public List<SanPhamModel> GetAllTop()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_sanpham_getalltop");
            return dt.ConvertTo<SanPhamModel>().ToList();

            //    return dt.Con
        }

        public List<SanPhamModel> GetAllByID(int id)
        {

            
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_sanpham_getallbyid","@MaSanPham",id);
            return dt.ConvertTo<SanPhamModel>().ToList();


            //    return dt.Con
        }

        public List<SanPhamModel> GetAllByTenM(string id)
        {


            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_sanpham_getallbyname", "@TenSanPham", id);
            return dt.ConvertTo<SanPhamModel>().ToList();


            //    return dt.Con
        }

        public List<SanPhamModel> GetAllByIDDM(int id)
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_sanpham_getallbyidDM", "@MaDanhMuc", id);
            return dt.ConvertTo<SanPhamModel>().ToList();
            //    return dt.Con
        }
    }
}

