﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public partial class ChiTietHoaDonNhapADMINReponsitory : IChiTietHoaDonNhapADMINReponsitory
    {

        private IDatabaseHelper _dbHelper;
        public ChiTietHoaDonNhapADMINReponsitory(IDatabaseHelper dbHelper)
        {
            _dbHelper = dbHelper;
        }

        public bool Create(HoaDonNhapADMINModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiethoadonnhapadmin_create",
                    "@MaHoaDonNhap", model.MaHoaDonNhap,
                    "@MaSanPham", model.MaSanPham,
                    "@SoLuongNhap", model.SoLuongNhap,
                    "@GiaNhap", model.GiaNhap,
                    "@TrangThai", model.TrangThai,
                    "@MaNhaCungCap", model.MaNhaCungCap
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    throw new Exception(Convert.ToString(result));
                    // return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Update(HoaDonNhapADMINModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiethoadonnhapadmin_update",

                    "@MaChiTietHoaDon", model.MaChiTietHoaDonNhap,
                   "@MaHoaDonNhap", model.MaHoaDonNhap,
                    "@MaSanPham", model.MaSanPham,
                    "@SoLuongNhap", model.SoLuongNhap,
                    "@GiaNhap", model.GiaNhap,
                    "@TrangThai", model.TrangThai,
                    "@MaNhaCungCap", model.MaNhaCungCap
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public bool Delete(string id)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiethoadonnhapadmin_delete",
                "@MaChiTietHoaDon", id
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<HoaDonNhapADModel> GetAll()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_chitiethoadonnhapadmin_getall");
            return dt.ConvertTo<HoaDonNhapADModel>().ToList();

            //    return dt.Con
        }

        public List<ThongKeDoanhThu> GetAllDT()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_thongkedoanhthu_getall");
            return dt.ConvertTo<ThongKeDoanhThu>().ToList();

            //    return dt.Con
        }


        public List<HoaDonNhapADMINModel> GetAllByID(int id)
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_chitiethoadonnhap_getallbyidhoadonnhap", "@MaHoaDonNhap", id);
            return dt.ConvertTo<HoaDonNhapADMINModel>().ToList();


            //    return dt.Con
        }


    }
}
