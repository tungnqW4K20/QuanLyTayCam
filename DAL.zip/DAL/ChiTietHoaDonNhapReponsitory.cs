﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DAL
{
    public partial class ChiTietHoaDonNhapReponsitory : IChiTietHoaDonNhapReponsitory
    {
        private IDatabaseHelper _dbHelper;
        public ChiTietHoaDonNhapReponsitory(IDatabaseHelper dbHelper)
        {
            _dbHelper = dbHelper;
        }

        public bool Create(ChiTietHoaDonNhapModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiethoadonnhap_create",
                    "@MaHoaDonNhap",model.MaHoaDonNhap,
                    "@MaSanPham",model.MaSanPham,
                    "@SoLuongNhap",model.SoLuongNhap,
                    "@GiaNhapMoi",model.GiaNhapMoi

                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    throw new Exception(Convert.ToString(result));
                    // return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Update(ChiTietHoaDonNhapModel model)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiethoadonnhap_update",

                    "@MaChiTietHoaDon",model.MaChiTietHoaDonNhap,
                    "@MaSanPham",model.MaSanPham,
                    "@SoLuongNhapMoi",model.SoLuongNhap
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public bool Delete(string id)
        {
            string msgError = "";
            try
            {
                var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_chitiethoadonnhap_delete",
                "@MaChiTietHoaDon", id
                );
                if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
                {
                    // throw new Exception(Convert.ToString(result) + msgError);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<ChiTietHoaDonNhapModel> GetAll()
        {
            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_chitiethoadonnhap_getall");
            return dt.ConvertTo<ChiTietHoaDonNhapModel>().ToList();

            //    return dt.Con
        }


       

        public List<ChiTietHoaDonNhapModel> GetAllByID(int id)
        {


            string msgError = "";
            var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_chitiethoadonnhap_getallbyidhoadonnhap", "@MaHoaDonNhap", id);
            return dt.ConvertTo<ChiTietHoaDonNhapModel>().ToList();


            //    return dt.Con
        }

        
    }
}

