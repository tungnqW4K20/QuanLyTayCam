﻿using DAL.Helper;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
	public partial class GioHangRepository : IGioHangRepository
	{
		private IDatabaseHelper _dbHelper;
		public GioHangRepository(IDatabaseHelper dbHelper)
		{
			_dbHelper = dbHelper;
		}
		public bool Create(GioHangModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_giohang_them",
					"@MaKhachHang",model.MaKhachHang,
					"@MaSP", model.MaSanPham
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					//   throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public bool Update(GioHangModel model)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_giohang_update",
					"@MaKhachHang", model.MaKhachHang,
					"@MaSP", model.MaSanPham,
					"@SoLuongMoi", model.SoLuongThem
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}



		public bool Delete(string id,string UserID)
		{
			string msgError = "";
			try
			{
				var result = _dbHelper.ExecuteScalarSProcedureWithTransaction(out msgError, "sp_giohang_delete",
				"@MaKhachHang", UserID, "@MaSP", id
				);
				if ((result != null && !string.IsNullOrEmpty(result.ToString())) || !string.IsNullOrEmpty(msgError))
				{
					// throw new Exception(Convert.ToString(result) + msgError);
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public List<GioHangModel> GetAll()
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_giohang_getall");//lấy toàn bộ bảng giỏ hàng ra
			return dt.ConvertTo<GioHangModel>().ToList();

			//    return dt.Con
		}


		public List<GioHangModel> GetAllTop()
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_giohang_getalltop");
			return dt.ConvertTo<GioHangModel>().ToList();
			//    return dt.Con
		}

		public List<GioHangKH1> GetAllByID(string id)
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_giohang_getallgiohangbyidKH", "@UserID", id);
			return dt.ConvertTo<GioHangKH1>().ToList();
			//    return dt.Con
		}

		/// <summary>
		/// api danh Frontend
		/// </summary>
		/// <param name="id"></param>
		/// <param name="UserID"></param>
		/// <returns></returns>
		public List<GioHangKH1> TangGH(string id, string UserID)
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_giohang_update", "@UserID", UserID, "@MaSP", id);
			return dt.ConvertTo<GioHangKH1>().ToList();
		}
		public List<GioHangKH1> GiamGH(string id, string UserID)
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_giohang_updategiam", "@UserID", UserID, "@MaSP", id);
			return dt.ConvertTo<GioHangKH1>().ToList();
		}

		public List<GioHangKH1> ThemGH(string id, string UserID)
		{
			string msgError = "";
			var dt = _dbHelper.ExecuteSProcedureReturnDataTable(out msgError, "sp_giohang_themgiohang", "@UserID", UserID, "@MaSP", id);
			return dt.ConvertTo<GioHangKH1>().ToList();
		}

	}
}
