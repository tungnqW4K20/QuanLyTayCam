﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NuGet.Common;
using System.Diagnostics;
using System.Text;
using WebShopTayCam.Models;

namespace WebShopTayCam.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
       // private readonly EmailService _emailService;

        private readonly HttpClient _httpClient;
		public HomeController(ILogger<HomeController> logger, HttpClient httpClient)
        {
            _logger = logger;
			_httpClient = httpClient;
          
        }

		public ActionResult DangXuat()
		{
			// Xóa Session
			 HttpContext.Session.Clear();
			//Session.Abandon();
			//HttpContext.Session.SetString("UserSesion", "");
			//gioHangs.Clear();
            // Chuyển hướng về trang đăng nhập
            return RedirectToAction("Index", "Home");
		}


        public IActionResult IndexSignin()
        {

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken] // Quan trọng để chống CSRF
        public async Task<IActionResult> IndexSignin(KhachHangTaiKhoanModel model)
        {
            if (ModelState.IsValid)
            {
                // 1. Kiểm tra xem Tài Khoản hoặc Email đã tồn tại chưa (nếu cần)
                //    Ví dụ:
                //    bool taiKhoanDaTonTai = await _khachHangService.KiemTraTaiKhoanTonTai(model.TaiKhoan);
                //    if (taiKhoanDaTonTai)
                //    {
                //        ModelState.AddModelError("TaiKhoan", "Tên tài khoản này đã được sử dụng.");
                //    }
                //    bool emailDaTonTai = await _khachHangService.KiemTraEmailTonTai(model.Email);
                //    if (emailDaTonTai)
                //    {
                //        ModelState.AddModelError("Email", "Email này đã được sử dụng để đăng ký.");
                //    }

                //    if (!ModelState.IsValid) // Kiểm tra lại sau khi thêm lỗi tùy chỉnh
                //    {
                //        return View(model);
                //    }

                // 2. Hash mật khẩu trước khi lưu vào database
                //    string hashedPassword = YourPasswordHashingFunction(model.MatKhau);
                //    model.MatKhau = hashedPassword; // Chỉ lưu hash, không lưu mật khẩu gốc

                // 3. Lưu thông tin khách hàng vào Database
                //    var result = await _khachHangService.TaoMoiKhachHang(model);
                //    if (result.Succeeded) // Hoặc kiểm tra theo cách service của bạn trả về
                //    {
                //        // Đăng ký thành công
                //        // Có thể tự động đăng nhập cho người dùng ở đây
                //        // Hoặc chuyển hướng đến trang đăng nhập/thông báo thành công
                //        TempData["SuccessMessage"] = "Đăng ký tài khoản thành công! Vui lòng đăng nhập.";
                //        return RedirectToAction("Login", "Account"); // Hoặc tên controller của bạn
                //    }
                //    else
                //    {
                //        // Xử lý lỗi từ service (nếu có)
                //        // foreach (var error in result.Errors)
                //        // {
                //        //     ModelState.AddModelError(string.Empty, error.Description);
                //        // }
                //    }

                try
                {
                    // Gửi request DELETE
                    var request = new HttpRequestMessage
                    {
                        Method = HttpMethod.Post,
                        RequestUri = new System.Uri("https://localhost:7268/api/KhachHang/createtkkh-item"),
                        Content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON

                    };

                    HttpResponseMessage response = await _httpClient.SendAsync(request);


                    if (response.IsSuccessStatusCode)
                    {

                        TempData["SuccessMessage"] = $"Đăng ký thành công cho tài khoản: {model.TaiKhoan}.";

                        return RedirectToAction("IndexLogin", "Home"); // Tạm thời chuyển hướng
                    }
                    else
                    {
                        TempData["SuccessMessage"] = $"Đăng ký thành công cho tài khoản: {model.TaiKhoan}";

                        return RedirectToAction("IndexLogin", "Home"); // Tạm thời chuyển hướng

                    }
                }
                catch (System.Exception ex)
                {
                    TempData["SuccessMessage"] = $"Đăng ký thành công cho tài khoản: {model.TaiKhoan}";

                    return RedirectToAction("IndexLogin", "Home"); // Tạm thời chuyển hướng

                }



              //  TempData["SuccessMessage"] = $"Đăng ký thành công cho tài khoản: {model.TaiKhoan}. (Đây là DEMO, chưa lưu DB)";

             //   return RedirectToAction("IndexLogin", "Home"); // Tạm thời chuyển hướng
            }

            // Nếu ModelState không hợp lệ, hiển thị lại form với các lỗi
            return View(model);
        }


        // Action để gọi API và trả về View
        public async Task<IActionResult> Index()
		{
			//// URL của API
			string apiUrl = "https://localhost:7268/api/SanPham/getalltop-item";
			List<SanPhamModel> categories = new List<SanPhamModel>();

			try
			{
				// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
				var response = await _httpClient.GetAsync(apiUrl);

				if (response.IsSuccessStatusCode)
				{
					// Đọc phản hồi JSON thành chuỗi
					var jsonString = await response.Content.ReadAsStringAsync();

					// Chuyển đổi JSON thành danh sách SanPham
					categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
				}
				else
				{
					// Xử lý trường hợp lỗi khi gọi API
					ViewBag.Error = "Không thể lấy dữ liệu từ API.";
				}
			}
			catch (HttpRequestException ex)
			{
				// Xử lý trường hợp có lỗi trong quá trình gọi API
				ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
			}

			ViewBag.sanpham = categories;
            var username = HttpContext.Session.GetString("UserSesion");

            ViewBag.UserName = username;

			ViewBag.sogh = gioHangs.Count;

            //Trả về View với dữ liệu
            return View(categories);
			//return View();
			
		}

	

        public async Task<IActionResult> IndexSPTimKiem(string id)
		{
			ViewBag.ID = id;
            ViewBag.sogh = gioHangs.Count;
            //// URL của API
            //string apiUrl = "https://localhost:7268/api/SanPham/getall-itembyidTenSP?id=" + id.ToString();
            //List<SanPhamModel> categories = new List<SanPhamModel>();

            //try
            //{
            //    // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
            //    var response = await _httpClient.GetAsync(apiUrl);

            //    if (response.IsSuccessStatusCode)
            //    {
            //        // Đọc phản hồi JSON thành chuỗi
            //        var jsonString = await response.Content.ReadAsStringAsync();

            //        // Chuyển đổi JSON thành danh sách SanPham
            //        categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
            //    }
            //    else
            //    {
            //        // Xử lý trường hợp lỗi khi gọi API
            //        ViewBag.Error = "Không thể lấy dữ liệu từ API.";
            //    }
            //}
            //catch (HttpRequestException ex)
            //{
            //    // Xử lý trường hợp có lỗi trong quá trình gọi API
            //    ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            //}

            // ViewBag.sanpham = categories;
            // Trả về View với dữ liệu
            //  return View(categories);
            return View();

        }

		[HttpPost]
        public async Task<IActionResult> GuiDanhGia(string id,int masp)
        {

            ViewBag.ID = id;
            var username = HttpContext.Session.GetString("UserSesion");

            var binhluan = new BinhLuanModel
            {
                MaBinhLuan = 0,
                MaKhachHang = 0,
                MaSanPham = masp,
                NoiDung = id,
                TenKhachHang = username,
                TrangThai=0
            };

            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new System.Uri("https://localhost:7268/api/BinhLuan/create-item"),
                    Content = new StringContent(JsonConvert.SerializeObject(binhluan), Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON

                };

                HttpResponseMessage response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {

                    return Json(new { success = true, message = "gửi thành công!" });
                }
                else
                {

                    return Json(new { success = false, message = "gửi thất bại!" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "gửi thất bại!" });
            }
  
        }


        [HttpPost]
        public async Task<IActionResult> AddComment(int MaBinhLuan, string NoiDung)
        {
            var username = HttpContext.Session.GetString("UserSesion");

            var chiTiet = new ChiTietBinhLuanModel
            {
                ID_BinhLuan = MaBinhLuan,
                NoiDung = NoiDung,
                DoiTuongBinhLuan = 1,
                NgayBinhLuan = DateTime.Now,
                TenKhachHang = username
            };

            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new System.Uri("https://localhost:7268/api/ChiTietBinhLuan/create-item"),
                    Content = new StringContent(JsonConvert.SerializeObject(chiTiet), Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON

                };

                HttpResponseMessage response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    return Json(new { success = true, message = "Bình luận đã được gửi thành công!" });
                }
                else
                {
                    return Json(new { success = false, message = "Không thể thêm bình luận" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Lỗi: " + ex.Message });
            }

        }

        public async Task<IActionResult> IndexSPTheoDM(string id)
        {
            ViewBag.sogh = gioHangs.Count;
            ViewBag.ID = id;
            // https://localhost:7268/api/SanPham/getall-itembyidDM?id=1
            // URL của API
            //string apiUrl = "https://localhost:7268/api/SanPham/getall-itembyidDM?id=" + id.ToString();
            //List<SanPhamModel> categories = new List<SanPhamModel>();

            //try
            //{
            //    // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
            //    var response = await _httpClient.GetAsync(apiUrl);

            //    if (response.IsSuccessStatusCode)
            //    {
            //        // Đọc phản hồi JSON thành chuỗi
            //        var jsonString = await response.Content.ReadAsStringAsync();

            //        // Chuyển đổi JSON thành danh sách SanPham
            //        categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
            //    }
            //    else
            //    {
            //        // Xử lý trường hợp lỗi khi gọi API
            //        ViewBag.Error = "Không thể lấy dữ liệu từ API.";
            //    }
            //}
            //catch (HttpRequestException ex)
            //{
            //    // Xử lý trường hợp có lỗi trong quá trình gọi API
            //    ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            //}

            //ViewBag.sanpham = categories;
            //// Trả về View với dữ liệu
            //return View(categories);
            return View();
        }

        [HttpPost]
		public async Task<IActionResult> SaveHoaDon(List<GioHangModel> selectedProducts)
		{
			var username = HttpContext.Session.GetString("UserSesion");

			string user1 = username;
			if (user1 == null)
			{
				user1 = "0";
			}

			if (selectedProducts == null || selectedProducts.Count == 0)
			{
				return Json(new { success = false, message = "Không có sản phẩm nào được chọn." });
			}

			// Tạo danh sách để lưu đơn hàng
			List<ThongTinHoaDonMoDel> gioHangHD = new List<ThongTinHoaDonMoDel>();

			// Xử lý thanh toán và lưu dữ liệu vào database
			foreach (var item in selectedProducts)
			{
				ThongTinHoaDonMoDel gioHangItem = new ThongTinHoaDonMoDel
				{
					MaSanPham = int.Parse(item.MaSanPham.ToString()),
					SoLuongBan = int.Parse(item.SoLuong.ToString()),
					DonGiaBan = decimal.Parse(item.Gia.ToString()),
					UserNameKH = user1 ?? "0"
				};

				// Thêm vào danh sách giỏ hàng
				gioHangHD.Add(gioHangItem);
			}

			if (username != null)
			{
				var apiUrl = "https://localhost:7268/api/ChiTietHoaDonBan/ThemHoaDon";

				try
				{
					// HTTP PUT: Gửi yêu cầu PUT tới API
					var response = await _httpClient.PostAsJsonAsync(apiUrl, gioHangHD);

				//	HttpContext.Session.SetString("UserSesion", "");

					// Kiểm tra phản hồi của API
					if (response.IsSuccessStatusCode)
					{
						// Thành công: Chuyển hướng về trang Index
						//return RedirectToAction("IndexHoaDonBan");
						return Json(new { success = true });
					}
					else
					{
						// Nếu lỗi, bạn có thể xử lý lỗi theo ý muốn
						ModelState.AddModelError(string.Empty, "Có lỗi xảy ra khi cập nhật hóa đơn");
						return Json(new { success = false });
					}
				}
				catch (Exception ex)
				{
					// Bắt lỗi nếu có
					ModelState.AddModelError(string.Empty, $"Lỗi khi gọi API: {ex.Message}");
				}

			}
			else
			{

				var apiUrl = "https://localhost:7268/api/KhachHang/create-item";
				var kh0 = selectedProducts[0];
				KhachHangModel khachhang = new KhachHangModel
				{
					MaKhachHang = int.Parse(kh0.MaKhachHang.ToString()),
					TenKH= kh0.TenKH,
					SDTKH = kh0.SDTKH,
					Email=kh0.Email,
					DiaChiKH=kh0.DiaChiKH

				};

				try
				{
					// HTTP PUT: Gửi yêu cầu PUT tới API
					var response = await _httpClient.PostAsJsonAsync(apiUrl, khachhang);

					// Kiểm tra phản hồi của API
					if (response.IsSuccessStatusCode)
					{
						// Thành công: Chuyển hướng về trang Index
						//return RedirectToAction("Index");
					}
					else
					{
						// Nếu lỗi, bạn có thể xử lý lỗi theo ý muốn
						ModelState.AddModelError(string.Empty, "Có lỗi xảy ra khi cập nhật khách hàng");
					}
				}
				catch (Exception ex)
				{
					// Bắt lỗi nếu có
					ModelState.AddModelError(string.Empty, $"Lỗi khi gọi API: {ex.Message}");
				}




				var apiUrl1 = "https://localhost:7268/api/ChiTietHoaDonBan/ThemHoaDon";

				try
				{
					// HTTP PUT: Gửi yêu cầu PUT tới API
					var response = await _httpClient.PostAsJsonAsync(apiUrl1, gioHangHD);

					//	HttpContext.Session.SetString("UserSesion", "");

					// Kiểm tra phản hồi của API
					if (response.IsSuccessStatusCode)
					{
						// Thành công: Chuyển hướng về trang Index
						//return RedirectToAction("IndexHoaDonBan");
						return Json(new { success = true });
					}
					else
					{
						// Nếu lỗi, bạn có thể xử lý lỗi theo ý muốn
						ModelState.AddModelError(string.Empty, "Có lỗi xảy ra khi cập nhật hóa đơn");
						return Json(new { success = false });
					}
				}
				catch (Exception ex)
				{
					// Bắt lỗi nếu có
					ModelState.AddModelError(string.Empty, $"Lỗi khi gọi API: {ex.Message}");
				}

			}


			return Json(new { success = true });

		}


		public async Task<IActionResult> IndexSP()
        {
            ViewBag.sogh = gioHangs.Count;
            //// URL của API
            string apiUrl = "https://localhost:7268/api/SanPham/getall-item";
			List<SanPhamModel> categories = new List<SanPhamModel>();

			try
			{
				// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
				var response = await _httpClient.GetAsync(apiUrl);

				if (response.IsSuccessStatusCode)
				{
					// Đọc phản hồi JSON thành chuỗi
					var jsonString = await response.Content.ReadAsStringAsync();

					// Chuyển đổi JSON thành danh sách SanPham
					categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
				}
				else
				{
					// Xử lý trường hợp lỗi khi gọi API
					ViewBag.Error = "Không thể lấy dữ liệu từ API.";
				}
			}
			catch (HttpRequestException ex)
			{
				// Xử lý trường hợp có lỗi trong quá trình gọi API
				ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
			}

			ViewBag.sanpham = categories;
            //Trả về View với dữ liệu


            string apiUrlDM = "https://localhost:7268/api/DanhMuc/getall-item";
            List<DanhMucModel> categoriesDM = new List<DanhMucModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlDM);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categoriesDM = JsonConvert.DeserializeObject<List<DanhMucModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.Categories = categoriesDM;


            return View(categories);

		//	return View();
        }

        public async Task<IActionResult> IndexCTSP(string id)
        {
            ViewBag.sogh = gioHangs.Count;
            var username = HttpContext.Session.GetString("UserSesion");

            ViewBag.ID = id;
            ViewBag.username = username;
            // URL của API
            string apiUrl = "https://localhost:7268/api/ChiTietSanPham/getall-itembyid?id=" + id;
			List<ChiTietSanPhamModel> categories = new List<ChiTietSanPhamModel>();

			try
			{
				// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
				var response = await _httpClient.GetAsync(apiUrl);

				if (response.IsSuccessStatusCode)
				{
					// Đọc phản hồi JSON thành chuỗi
					var jsonString = await response.Content.ReadAsStringAsync();

					// Chuyển đổi JSON thành danh sách SanPham
					categories = JsonConvert.DeserializeObject<List<ChiTietSanPhamModel>>(jsonString);
				}
				else
				{
					// Xử lý trường hợp lỗi khi gọi API
					ViewBag.Error = "Không thể lấy dữ liệu từ API.";
				}
			}
			catch (HttpRequestException ex)
			{
				// Xử lý trường hợp có lỗi trong quá trình gọi API
				ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
			}


			var fristitem = categories[0];

  
            ViewBag.TenSanPham = fristitem.TenSanPham;
			ViewBag.NoiDungChiTiet = fristitem.NoiDungChiTiet;
			ViewBag.Anh1 = fristitem.Anh1;
			ViewBag.Anh2 = fristitem.Anh2;
			ViewBag.Anh3 = fristitem.Anh3;
			ViewBag.Anh4 = fristitem.Anh4;
			ViewBag.CPU = fristitem.CPU;
			ViewBag.Gia = fristitem.Gia;
			ViewBag.MaSanPham = fristitem.MaSanPham;
			ViewBag.GPU = fristitem.GPU;
			ViewBag.Storage = fristitem.Storage;
			ViewBag.HienThi = fristitem.HienThi;
			ViewBag.TrongLuong = fristitem.TrongLuong;
			ViewBag.KichThuoc = fristitem.KichThuoc;
			ViewBag.Video = fristitem.Video;
			ViewBag.sanpham = categories;



            string apiSP = "https://localhost:7268/api/BinhLuan/GetAllBinhLuanTheoSP-item?id=" + id.ToString();
            List<BinhLuanTenSPModel> categoriesBL = new List<BinhLuanTenSPModel>();
            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiSP);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categoriesBL = JsonConvert.DeserializeObject<List<BinhLuanTenSPModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }



            string apichitietbl = "https://localhost:7268/api/ChiTietBinhLuan/GetAllCTBinhLuanTheoSP-item?id=" + id.ToString();
            List<ChiTietBinhLuanModel> categoriesCTBL = new List<ChiTietBinhLuanModel>();
            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apichitietbl);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categoriesCTBL = JsonConvert.DeserializeObject<List<ChiTietBinhLuanModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }



            var model = new BinhLuanViewModel
            {
                BinhLuans = categoriesBL,
                ChiTietBinhLuans = categoriesCTBL
            };



            // Trả về View với dữ liệu
            return View(model);
        }

		public async Task<IActionResult> IndexHoaDonBan()
		{ //lừa cho load html lên đã
			// URL của API
			string apiUrl = "https://localhost:7268/api/HoaDonBan/gettopmax";
			List<HoaDonKhachHangModel> categories = new List<HoaDonKhachHangModel>();
            ViewBag.sogh = gioHangs.Count;
            try
			{
				// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
				var response = await _httpClient.GetAsync(apiUrl);

				if (response.IsSuccessStatusCode)
				{
					// Đọc phản hồi JSON thành chuỗi
					var jsonString = await response.Content.ReadAsStringAsync();

					// Chuyển đổi JSON thành danh sách SanPham
					categories = JsonConvert.DeserializeObject<List<HoaDonKhachHangModel>>(jsonString);
				}
				else
				{
					// Xử lý trường hợp lỗi khi gọi API
					ViewBag.Error = "Không thể lấy dữ liệu từ API.";
				}
			}
			catch (HttpRequestException ex)
			{
				// Xử lý trường hợp có lỗi trong quá trình gọi API
				ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
			}
			var hd0 = categories[0];
			ViewBag.TenKH = hd0.TenKH;
			ViewBag.DiaChi = hd0.DiaChiKH;

			ViewBag.NgayLap = hd0.NgayLap;

			ViewBag.hoadonban = categories;

           // decimal totalprice = categories.Sum(i => int.Parse(i.ThanhTien ?? 0));


            decimal tongThanhTien = 0;

            foreach (var hoaDon in categories)
            {
                if (decimal.TryParse(hoaDon.ThanhTien, out decimal thanhTien))
                {
                    tongThanhTien += thanhTien;
                }
            }

            ViewBag.totalprice = tongThanhTien;


            decimal totalpriceThue = tongThanhTien / 10;
            ViewBag.totalpriceThue = totalpriceThue;

            decimal totalcong = tongThanhTien + totalpriceThue;
            ViewBag.totalcong = totalcong;

            // Trả về View với dữ liệu
            return View(categories);
		}


        public async Task<IActionResult> IndexLogin()
        { //lừa cho load html lên đã
          // URL của API
            //string apiUrl = "https://localhost:7268/api/SanPham/getalltop-item";
            //List<SanPhamModel> categories = new List<SanPhamModel>();

            //try
            //{
            //    // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
            //    var response = await _httpClient.GetAsync(apiUrl);

            //    if (response.IsSuccessStatusCode)
            //    {
            //        // Đọc phản hồi JSON thành chuỗi
            //        var jsonString = await response.Content.ReadAsStringAsync();

            //        // Chuyển đổi JSON thành danh sách SanPham
            //        categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
            //    }
            //    else
            //    {
            //        // Xử lý trường hợp lỗi khi gọi API
            //        ViewBag.Error = "Không thể lấy dữ liệu từ API.";
            //    }
            //}
            //catch (HttpRequestException ex)
            //{
            //    // Xử lý trường hợp có lỗi trong quá trình gọi API
            //    ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            //}

            //ViewBag.sanpham = categories;
            //HttpContext.Session.SetString("UserSesion",UserName);
            // Trả về View với dữ liệu
            return View();
        }
        const string CART_KEY = "MYCART";
        // khai bao gio hang
        public List<GioHang> gioHangs => HttpContext.Session.Get<List<GioHang>>
            (CART_KEY) ?? new List<GioHang>();

		public async Task<IActionResult> ThemGioHang(int id)
        {
			// URL của API
		

			var username  = HttpContext.Session.GetString("UserSesion");
			int MaSP = id;
			if (username != null)
			{
				string apiUrl = "https://localhost:7268/api/GioHang/getall-itembyidThemGH?id=" + id + "&UserID=" + username;
				List<GioHang> categories = new List<GioHang>();

				try
				{
					// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
					var response = await _httpClient.GetAsync(apiUrl);

					if (response.IsSuccessStatusCode)
					{
						// Đọc phản hồi JSON thành chuỗi
						var jsonString = await response.Content.ReadAsStringAsync();

						// Chuyển đổi JSON thành danh sách SanPham
						categories = JsonConvert.DeserializeObject<List<GioHang>>(jsonString);
					}
					else
					{
						// Xử lý trường hợp lỗi khi gọi API
						ViewBag.Error = "Không thể lấy dữ liệu từ API.";
					}
				}
				catch (HttpRequestException ex)
				{
					// Xử lý trường hợp có lỗi trong quá trình gọi API
					ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
				}



				//	HttpContext.Session.Set(CART_KEY, categories);

				return RedirectToAction("IndexGH");
			}
			else
			{

				string apiUrl = "https://localhost:7268/api/SanPham/getall-itembyid?id=" + id;
				List<SanPhamModel> categories = new List<SanPhamModel>();

				try
				{
					// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
					var response = await _httpClient.GetAsync(apiUrl);

					if (response.IsSuccessStatusCode)
					{
						// Đọc phản hồi JSON thành chuỗi
						var jsonString = await response.Content.ReadAsStringAsync();

						// Chuyển đổi JSON thành danh sách SanPham
						categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
					}
					else
					{
						// Xử lý trường hợp lỗi khi gọi API
						ViewBag.Error = "Không thể lấy dữ liệu từ API.";
					}
				}
				catch (HttpRequestException ex)
				{
					// Xử lý trường hợp có lỗi trong quá trình gọi API
					ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
				}

				var fisrtitem = categories[0];
				//	ViewBag.sanpham = categories;
				var giohang = gioHangs;
				var item = giohang.SingleOrDefault(p => p.MaSanPham == id);
				if (item == null)
				{
					item = new GioHang
					{
						MaSanPham = fisrtitem.MaSanPham,
						TenSanPham = fisrtitem.TenSanPham,
						Gia = (decimal)fisrtitem.Gia,
						SoLuong = 1,
						HinhAnh = fisrtitem.HinhAnh
					};
					giohang.Add(item);

				}
				else
				{
					item.SoLuong += 1;
				}
				//set session
				HttpContext.Session.Set(CART_KEY, giohang); //bỏ là ngu người


			}

			return RedirectToAction("IndexGH");

		}

        public async Task<IActionResult> ThemGioHang2(int id)
        {
            // URL của API


            var username = HttpContext.Session.GetString("UserSesion");
            int MaSP = id;
            if (username != null)
            {
                string apiUrl = "https://localhost:7268/api/GioHang/getall-itembyidThemGH?id=" + id + "&UserID=" + username;
                List<GioHang> categories = new List<GioHang>();

                try
                {
                    // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                    var response = await _httpClient.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        // Đọc phản hồi JSON thành chuỗi
                        var jsonString = await response.Content.ReadAsStringAsync();

                        // Chuyển đổi JSON thành danh sách SanPham
                        categories = JsonConvert.DeserializeObject<List<GioHang>>(jsonString);
                    }
                    else
                    {
                        // Xử lý trường hợp lỗi khi gọi API
                        ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                    }
                }
                catch (HttpRequestException ex)
                {
                    // Xử lý trường hợp có lỗi trong quá trình gọi API
                    ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
                }



                //	HttpContext.Session.Set(CART_KEY, categories);
                TempData["SuccessMessage"] = "Thêm vào giỏ hàng thành công!";
                return RedirectToAction("Index");
            }
            else
            {

                string apiUrl = "https://localhost:7268/api/SanPham/getall-itembyid?id=" + id;
                List<SanPhamModel> categories = new List<SanPhamModel>();

                try
                {
                    // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                    var response = await _httpClient.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        // Đọc phản hồi JSON thành chuỗi
                        var jsonString = await response.Content.ReadAsStringAsync();

                        // Chuyển đổi JSON thành danh sách SanPham
                        categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
                    }
                    else
                    {
                        // Xử lý trường hợp lỗi khi gọi API
                        ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                    }
                }
                catch (HttpRequestException ex)
                {
                    // Xử lý trường hợp có lỗi trong quá trình gọi API
                    ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
                }

                var fisrtitem = categories[0];
                //	ViewBag.sanpham = categories;
                var giohang = gioHangs;
                var item = giohang.SingleOrDefault(p => p.MaSanPham == id);
                if (item == null)
                {
                    item = new GioHang
                    {
                        MaSanPham = fisrtitem.MaSanPham,
                        TenSanPham = fisrtitem.TenSanPham,
                        Gia = (decimal)fisrtitem.Gia,
                        SoLuong = 1,
                        HinhAnh = fisrtitem.HinhAnh
                    };
                    giohang.Add(item);

                }
                else
                {
                    item.SoLuong += 1;
                }
                //set session
                HttpContext.Session.Set(CART_KEY, giohang); //bỏ là ngu người


            }
            TempData["SuccessMessage"] = "Thêm vào giỏ hàng thành công!";
            return RedirectToAction("Index");

        }


        public  IActionResult GanSesion(string id)
		{
            HttpContext.Session.SetString("UserSesion", id);
            return RedirectToAction("Index");

		}


		[HttpPost]
		public async Task<JsonResult> increaseQuantity(int id)
		{

			var user = HttpContext.Session.GetString("UserSesion");
			if (user != null)
			{
				//https://localhost:7268/api/GioHang/getall-itembyidTangGH?id=1&UserID=test
				string apiUrl = "https://localhost:7268/api/GioHang/getall-itembyidTangGH?id=" + id + "&UserID=" + user;
				List<GioHang> categories = new List<GioHang>();

				try
				{
					// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
					var response = await _httpClient.GetAsync(apiUrl);

					if (response.IsSuccessStatusCode)
					{
						// Đọc phản hồi JSON thành chuỗi
						var jsonString = await response.Content.ReadAsStringAsync();

						// Chuyển đổi JSON thành danh sách SanPham
						categories = JsonConvert.DeserializeObject<List<GioHang>>(jsonString);
					}
					else
					{
						// Xử lý trường hợp lỗi khi gọi API
						ViewBag.Error = "Không thể lấy dữ liệu từ API.";
					}
				}
				catch (HttpRequestException ex)
				{
					// Xử lý trường hợp có lỗi trong quá trình gọi API
					ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
				}



				//	HttpContext.Session.Set(CART_KEY, categories);

				decimal totalPrice = categories.Sum(i => i.Gia * i.SoLuong);

				return Json(new { success = true, newQuantity = 1,SL=1, totalPrice = totalPrice });

			}


			var giohang = gioHangs;
			var item = giohang.SingleOrDefault(p => p.MaSanPham == id);
			// Tìm sản phẩm cần cập nhật
			// var item = Cart.FirstOrDefault(i => i.MaSanPham == id);
			if (item != null)
			{
				item.SoLuong++;
				// Cập nhật giỏ hàng trong Session
				// Session["Cart"] = cart;\
				HttpContext.Session.Set(CART_KEY, giohang);

				decimal totalPrice = giohang.Sum(i => i.Gia * i.SoLuong);

				return Json(new { success = true, newQuantity = item.SoLuong , totalPrice = totalPrice });
			}

			return Json(new { success = false });
		}


		[HttpPost]

		public async Task<JsonResult> decreaseQuantity(int id)
		{


			var user = HttpContext.Session.GetString("UserSesion");
			if (user != null)
			{
				//https://localhost:7268/api/GioHang/getall-itembyidTangGH?id=1&UserID=test
				string apiUrl = "https://localhost:7268/api/GioHang/getall-itembyidGiamGH?id=" + id + "&UserID=" + user;
				List<GioHang> categories = new List<GioHang>();

				try
				{
					// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
					var response = await _httpClient.GetAsync(apiUrl);

					if (response.IsSuccessStatusCode)
					{
						// Đọc phản hồi JSON thành chuỗi
						var jsonString = await response.Content.ReadAsStringAsync();

						// Chuyển đổi JSON thành danh sách SanPham
						categories = JsonConvert.DeserializeObject<List<GioHang>>(jsonString);
					}
					else
					{
						// Xử lý trường hợp lỗi khi gọi API
						ViewBag.Error = "Không thể lấy dữ liệu từ API.";
					}
				}
				catch (HttpRequestException ex)
				{
					// Xử lý trường hợp có lỗi trong quá trình gọi API
					ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
				}



				//	HttpContext.Session.Set(CART_KEY, categories);

				decimal totalPrice = categories.Sum(i => i.Gia * i.SoLuong);

				return Json(new { success = true, newQuantity = 1, SL = 1, totalPrice = totalPrice });

			}



			var giohang = gioHangs;
			var item = giohang.SingleOrDefault(p => p.MaSanPham == id);
			// Tìm sản phẩm cần cập nhật
			// var item = Cart.FirstOrDefault(i => i.MaSanPham == id);
			if (item != null)
			{
				item.SoLuong--;
                if (item.SoLuong < 1)
                {
                    item.SoLuong = 1;
                }
				// Cập nhật giỏ hàng trong Session
				// Session["Cart"] = cart;
				HttpContext.Session.Set(CART_KEY, giohang);


				decimal totalPrice = giohang.Sum(i => i.Gia * i.SoLuong);



				return Json(new { success = true, newQuantity = item.SoLuong, totalPrice = totalPrice });
			}


			return Json(new { success = false });
		}




		[HttpPost]
		public async  Task<JsonResult> removeItem(int id)
		{

			//https://localhost:7268/api/GioHang/delete-item?id=0&UserID=test

			var user = HttpContext.Session.GetString("UserSesion");
			if (user != null)
			{

				string apiUrl = "https://localhost:7268/api/GioHang/delete-item?id=" + id + "&UserID=" + user;
				List<GioHang> categories = new List<GioHang>();

				try
				{
					// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
					var response = await _httpClient.DeleteAsync(apiUrl);

					if (response.IsSuccessStatusCode)
					{

						decimal totalPrice = categories.Sum(i => i.Gia * i.SoLuong);

						return Json(new { success = true, newQuantity = 1, SL = 1, totalPrice = totalPrice });

						// Đọc phản hồi JSON thành chuỗi
						//var jsonString = await response.Content.ReadAsStringAsync();

						// Chuyển đổi JSON thành danh sách SanPham
						///categories = JsonConvert.DeserializeObject<List<GioHang>>(jsonString);

					}
					else
					{
						decimal totalPrice = categories.Sum(i => i.Gia * i.SoLuong);

						return Json(new { success = false, newQuantity = 1, SL = 1, totalPrice = totalPrice });

						// Xử lý trường hợp lỗi khi gọi API
						ViewBag.Error = "Không thể lấy dữ liệu từ API.";
					}
				}
				catch (HttpRequestException ex)
				{
					// Xử lý trường hợp có lỗi trong quá trình gọi API
					ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
				}

			

				//	HttpContext.Session.Set(CART_KEY, categories);


			}



			var giohang = gioHangs;
			var item = giohang.SingleOrDefault(p => p.MaSanPham == id);
			// Tìm sản phẩm cần cập nhật
			// var item = Cart.FirstOrDefault(i => i.MaSanPham == id);
			if (item != null)
			{
                giohang.Remove(item);
				// Cập nhật giỏ hàng trong Session
				// Session["Cart"] = cart;
				HttpContext.Session.Set(CART_KEY, giohang);

				decimal totalPrice = giohang.Sum(i => i.Gia * i.SoLuong);

				return Json(new { success = true, newQuantity = item.SoLuong, totalPrice = totalPrice });
			}

			return Json(new { success = false });
		}
		public async Task<IActionResult> IndexGH()
		{
            ViewBag.sogh = gioHangs.Count;
            var user = HttpContext.Session.GetString("UserSesion");
			if (user != null)
			{

				string apiUrl = "https://localhost:7268/api/GioHang/getall-itembyid?id=" + user;
				List<GioHang> categories = new List<GioHang>();

				try
				{
					// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
					var response = await _httpClient.GetAsync(apiUrl);

					if (response.IsSuccessStatusCode)
					{
						// Đọc phản hồi JSON thành chuỗi
						var jsonString = await response.Content.ReadAsStringAsync();

						// Chuyển đổi JSON thành danh sách SanPham
						categories = JsonConvert.DeserializeObject<List<GioHang>>(jsonString);
					}
					else
					{
						// Xử lý trường hợp lỗi khi gọi API
						ViewBag.Error = "Không thể lấy dữ liệu từ API.";
					}
				}
				catch (HttpRequestException ex)
				{
					// Xử lý trường hợp có lỗi trong quá trình gọi API
					ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
				}


				HttpContext.Session.Set(CART_KEY, categories);
				//lay thong khac hang tu user da dang nhap

				string apiUrl1 = "https://localhost:7268/api/KhachHang/getall-itembyiduser?id=" + user;
				List<KhachHangModel> kh = new List<KhachHangModel>();

				try
				{
					// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
					var response = await _httpClient.GetAsync(apiUrl1);

					if (response.IsSuccessStatusCode)
					{
						// Đọc phản hồi JSON thành chuỗi
						var jsonString = await response.Content.ReadAsStringAsync();

						// Chuyển đổi JSON thành danh sách SanPham
						kh = JsonConvert.DeserializeObject<List<KhachHangModel>>(jsonString);
					}
					else
					{
						// Xử lý trường hợp lỗi khi gọi API
						ViewBag.Error = "Không thể lấy dữ liệu từ API.";
					}
				}
				catch (HttpRequestException ex)
				{
					// Xử lý trường hợp có lỗi trong quá trình gọi API
					ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
				}

				var kh0 = kh[0];
				ViewBag.TenKH = kh0.TenKH;
				ViewBag.SDTKH = kh0.SDTKH;
				ViewBag.Email = kh0.Email;
				ViewBag.DiaChiKH = kh0.DiaChiKH;

			}

			decimal totalprice = gioHangs.Sum(i => i.Gia * i.SoLuong); ;
			ViewBag.totalprice = totalprice;

			return View(gioHangs);

		}




		public async Task<IActionResult> IndexBao()
        { //lừa cho load html lên đã
          // URL của API
            ViewBag.sogh = gioHangs.Count;
            string apiUrl = "https://localhost:7268/api/SanPham/getalltop-item";
            List<SanPhamModel> categories = new List<SanPhamModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.sanpham = categories;
            // Trả về View với dữ liệu
            return View(categories);
        }





        



        [HttpPost]
        public async Task<IActionResult> CreateKH([FromBody] KhachHangModel2 kh)
        {

            var user = HttpContext.Session.GetString("UserSesion");
            

             var apiUrl = "https://localhost:7268/api/KhachHang/update-itemtheouser";

            KhachHangModel2 khachhang = new KhachHangModel2
            {
                MaKhachHang = user,
                TenKH = kh.TenKH,
                SDTKH = kh.SDTKH,
                Email = kh.Email,
                DiaChiKH = kh.DiaChiKH

            };

            try
			{
				// HTTP PUT: Gửi yêu cầu PUT tới API
				var response = await _httpClient.PutAsJsonAsync(apiUrl, khachhang);

				// Kiểm tra phản hồi của API
				if (response.IsSuccessStatusCode)
				{
					// Thành công: Chuyển hướng về trang Index
					return RedirectToAction("IndexTTCN");
				}
				else
				{
					// Nếu lỗi, bạn có thể xử lý lỗi theo ý muốn
					ModelState.AddModelError(string.Empty, "Có lỗi xảy ra khi cập nhật khách hàng");
				}
			}
			catch (Exception ex)
			{
				// Bắt lỗi nếu có
				ModelState.AddModelError(string.Empty, $"Lỗi khi gọi API: {ex.Message}");
			}

			// Nếu có lỗi hoặc không thành công, trả về view với lỗi
			return View();


		}

		[HttpGet]
		public async Task<IActionResult> ViewChiTietHoaDon(int id)
		{


            var apiUrl = "https://localhost:7268/api/ChiTietHoaDonBan/getall-itembyidmahd?id="+id.ToString();

            List<ChiTietHDBanKHModel> categories = new List<ChiTietHDBanKHModel>();

            try
            {
				// HTTP PUT: Gửi yêu cầu PUT tới API
				var response = await _httpClient.GetAsync(apiUrl);

				// Kiểm tra phản hồi của API
				if (response.IsSuccessStatusCode)
                { 
					// Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categories = JsonConvert.DeserializeObject<List<ChiTietHDBanKHModel>>(jsonString);

                }
				else
				{
					// Nếu lỗi, bạn có thể xử lý lỗi theo ý muốn
					ModelState.AddModelError(string.Empty, "Có lỗi xảy ra khi cập nhật khách hàng");
				}
			}
			catch (Exception ex)
			{
				// Bắt lỗi nếu có
				ModelState.AddModelError(string.Empty, $"Lỗi khi gọi API: {ex.Message}");
			}

			var cthd = categories[0];
			ViewBag.MaHoaDonBan = cthd.MaHoaDonBan;
			ViewBag.NgayBan = cthd.NgayBan;
			ViewBag.TrangThai = cthd.TrangThai;
			ViewBag.TongTien = cthd.TongTien;

            // Nếu có lỗi hoặc không thành công, trả về view với lỗi
            return PartialView("_ChiTietHoaDonBan",categories);


		}



		[HttpPost]
		public async Task<JsonResult> IndexLogin([FromBody] LoginModel login)
		{
			var apiUrl = "https://localhost:7268/api/Login/login-KH";

			try
			{
				// HTTP PUT: Gửi yêu cầu PUT tới API
				var response = await _httpClient.PostAsJsonAsync(apiUrl, login);

				// Kiểm tra phản hồi của API
				if (response.IsSuccessStatusCode)
				{

					HttpContext.Session.SetString("UserSesion", login.UserName);

					// Thành công: Chuyển hướng về trang Index
					return Json(new { success = true });
				}
				else
				{
					// Nếu lỗi, bạn có thể xử lý lỗi theo ý muốn
					ModelState.AddModelError(string.Empty, "Đăng nhập thất bại");
				}
			}
			catch (Exception ex)
			{
				// Bắt lỗi nếu có
				ModelState.AddModelError(string.Empty, $"Lỗi khi gọi API: {ex.Message}");
			}

			// Nếu có lỗi hoặc không thành công, trả về view với lỗi
			return Json(new { success = false });


		}

		public async Task<IActionResult> IndexDM()
		{ //lừa cho load html lên đã
          // URL của API
            ViewBag.sogh = gioHangs.Count;
            string apiUrl = "https://localhost:7268/api/SanPham/getalltop-item";
			List<SanPhamModel> categories = new List<SanPhamModel>();

			try
			{
				// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
				var response = await _httpClient.GetAsync(apiUrl);

				if (response.IsSuccessStatusCode)
				{
					// Đọc phản hồi JSON thành chuỗi
					var jsonString = await response.Content.ReadAsStringAsync();

					// Chuyển đổi JSON thành danh sách SanPham
					categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
				}
				else
				{
					// Xử lý trường hợp lỗi khi gọi API
					ViewBag.Error = "Không thể lấy dữ liệu từ API.";
				}
			}
			catch (HttpRequestException ex)
			{
				// Xử lý trường hợp có lỗi trong quá trình gọi API
				ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
			}

			ViewBag.sanpham = categories;
			// Trả về View với dữ liệu
			return View(categories);
		}



        public class EmailService
        {
            private readonly HttpClient _httpClient;
            private readonly string _serviceId = "YOUR_SERVICE_ID";
            private readonly string _templateId = "YOUR_TEMPLATE_ID";
            private readonly string _publicKey = "YOUR_PUBLIC_KEY";

            public EmailService(HttpClient httpClient)
            {
                _httpClient = httpClient;
            }

            public async Task SendEmailAsync(string toEmail, string subject, string message)
            {
                var url = $"https://api.emailjs.com/api/v1.0/email/send";
                var emailData = new
                {
                    service_id = _serviceId,
                    template_id = _templateId,
                    user_id = _publicKey,
                    template_params = new
                    {
                        to_email = toEmail,
                        subject = subject,
                        message = message
                    }
                };

                var content = new StringContent(JsonConvert.SerializeObject(emailData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync(url, content);

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception("Failed to send email");
                }
            }
        }

        //[HttpPost]
        //public async Task<IActionResult> SendEmail(string toEmail, string subject, string message)
        //{
        //    try
        //    {
        //        await _emailService.SendEmailAsync(toEmail, subject, message);
        //        return Ok("Email sent successfully.");
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest($"Error sending email: {ex.Message}");
        //    }
        //}


        public async Task<IActionResult> IndexLienHe()
		{
            ViewBag.sogh = gioHangs.Count;
            // URL của API
            //string apiUrl = "https://localhost:7268/api/SanPham/getalltop-item";
            //List<SanPhamModel> categories = new List<SanPhamModel>();

            //try
            //{
            //	// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
            //	var response = await _httpClient.GetAsync(apiUrl);

            //	if (response.IsSuccessStatusCode)
            //	{
            //		// Đọc phản hồi JSON thành chuỗi
            //		var jsonString = await response.Content.ReadAsStringAsync();

            //		// Chuyển đổi JSON thành danh sách SanPham
            //		categories = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);
            //	}
            //	else
            //	{
            //		// Xử lý trường hợp lỗi khi gọi API
            //		ViewBag.Error = "Không thể lấy dữ liệu từ API.";
            //	}
            //}
            //catch (HttpRequestException ex)
            //{
            //	// Xử lý trường hợp có lỗi trong quá trình gọi API
            //	ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            //}

            //ViewBag.sanpham = categories;
            // Trả về View với dữ liệu


            return View();
		}



		public async Task<IActionResult> IndexTTCN()
        {
            ViewBag.sogh = gioHangs.Count;
            // URL của API
            List<HoaDonDatHangModel> categories = new List<HoaDonDatHangModel>();

			var user = HttpContext.Session.GetString("UserSesion");
			if (user != null)
			{

				string apiUrl = "https://localhost:7268/api/HoaDonBan/getall-itembyidtheouser?id=" + user;

				try
				{
					// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
					var response = await _httpClient.GetAsync(apiUrl);

					if (response.IsSuccessStatusCode)
					{
						// Đọc phản hồi JSON thành chuỗi
						var jsonString = await response.Content.ReadAsStringAsync();

						// Chuyển đổi JSON thành danh sách SanPham
						categories = JsonConvert.DeserializeObject<List<HoaDonDatHangModel>>(jsonString);
					}
					else
					{
						// Xử lý trường hợp lỗi khi gọi API
						ViewBag.Error = "Không thể lấy dữ liệu từ API.";
					}
				}
				catch (HttpRequestException ex)
				{
					// Xử lý trường hợp có lỗi trong quá trình gọi API
					ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
				}


				HttpContext.Session.Set(CART_KEY, categories);
				//lay thong khac hang tu user da dang nhap

				string apiUrl1 = "https://localhost:7268/api/KhachHang/getall-itembyiduser?id=" + user;
				List<KhachHangModel> kh = new List<KhachHangModel>();

				try
				{
					// Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
					var response = await _httpClient.GetAsync(apiUrl1);

					if (response.IsSuccessStatusCode)
					{
						// Đọc phản hồi JSON thành chuỗi
						var jsonString = await response.Content.ReadAsStringAsync();

						// Chuyển đổi JSON thành danh sách SanPham
						kh = JsonConvert.DeserializeObject<List<KhachHangModel>>(jsonString);
					}
					else
					{
						// Xử lý trường hợp lỗi khi gọi API
						ViewBag.Error = "Không thể lấy dữ liệu từ API.";
					}
				}
				catch (HttpRequestException ex)
				{
					// Xử lý trường hợp có lỗi trong quá trình gọi API
					ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
				}

				var kh0 = kh[0];
				ViewBag.TenKH = kh0.TenKH;
				ViewBag.SDTKH = kh0.SDTKH;
				ViewBag.Email = kh0.Email;
				ViewBag.DiaChiKH = kh0.DiaChiKH;


			}



			// Trả về View với dữ liệu
			return View(categories);
        }




        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}