document.addEventListener('DOMContentLoaded', function() {
            // Single Line Chart
            var ctx1 = document.getElementById('singleLineChart').getContext('2d');
            new Chart(ctx1, {
                type: 'line',
                data: {
                    labels: [50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150],
                    datasets: [{
                        label: 'Sales',
                        data: [8, 9, 10, 10, 11, 12, 13, 14, 14, 14, 15],
                        borderColor: 'rgba(54, 162, 235, 1)',
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });

            // Multiple Line Chart
            var ctx2 = document.getElementById('multipleLineChart').getContext('2d');
            new Chart(ctx2, {
                type: 'line',
                data: {
                    labels: [2016, 2017, 2018, 2019, 2020, 2021, 2022],
                    datasets: [
                        {
                            label: 'Sales',
                            data: [50, 60, 70, 80, 90, 100, 110],
                            borderColor: 'rgba(54, 162, 235, 1)',
                            backgroundColor: 'rgba(54, 162, 235, 0.2)',
                            fill: true
                        },
                        {
                            label: 'Revenue',
                            data: [50, 75, 80, 85, 100, 110, 120],
                            borderColor: 'rgba(75, 192, 192, 1)',
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });

            // Single Bar Chart
            var ctx3 = document.getElementById('singleBarChart').getContext('2d');
            new Chart(ctx3, {
                type: 'bar',
                data: {
                    labels: ['Italy', 'France', 'Spain', 'USA', 'Argentina'],
                    datasets: [{
                        label: 'Population',
                        data: [50, 45, 40, 25, 20],
                        backgroundColor: 'rgba(54, 162, 235, 0.5)'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });

            // Multiple Bar Chart
            var ctx4 = document.getElementById('multipleBarChart').getContext('2d');
            new Chart(ctx4, {
                type: 'bar',
                data: {
                    labels: [2016, 2017, 2018, 2019, 2020, 2021, 2022],
                    datasets: [
                        {
                            label: 'USA',
                            data: [20, 30, 40, 50, 60, 70, 80],
                            backgroundColor: 'rgba(54, 162, 235, 0.5)'
                        },
                        {
                            label: 'UK',
                            data: [10, 20, 30, 40, 50, 60, 70],
                            backgroundColor: 'rgba(75, 192, 192, 0.5)'
                        },
                        {
                            label: 'AU',
                            data: [5, 15, 25, 35, 45, 55, 65],
                            backgroundColor: 'rgba(255, 159, 64, 0.5)'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        });
		
		
		
		
		// Pie Chart
var ctx5 = document.getElementById('pieChart').getContext('2d');
new Chart(ctx5, {
    type: 'pie',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple'],
        datasets: [{
            label: 'Distribution',
            data: [12, 19, 3, 5, 2],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'right', // Đặt chú thích bên phải
                labels: {
                    boxWidth: 10,
                    padding: 15
                }
            }
        }
    }
});

		
		
		