// Hàm hiển thị thông báo
        function showNotification(message) {
            const notification = document.getElementById('notification');
            notification.textContent = message;
            notification.classList.add('show');
            
        }
//-----------GIỎ HÀNG---------------
        
function showNotification(message) {
    alert(message);
}

document.getElementById("buyNow").addEventListener("click", function(event) {
    event.preventDefault();

    const product = {
		id:ID_product,
        name: document.querySelector(".product-info h1").innerText.trim(),
        price: parseFloat(document.querySelector(".product-info p").innerText.replace(/\D/g, '')),
        image: document.getElementById("currentImage").src,
        quantity: 1
    };

    let cartItems = JSON.parse(localStorage.getItem('cartItems1')) || [];
    const existingItemIndex = cartItems.findIndex(item => item.name === product.name);

    if (existingItemIndex >= 0) {
        if (confirm("Sản phẩm đã có trong giỏ hàng. Bạn vẫn muốn thêm ?")) {
            cartItems[existingItemIndex].quantity += 1;
            localStorage.setItem('cartItems1', JSON.stringify(cartItems));
            showNotification("Số lượng sản phẩm này trong giỏ hàng đã tăng lên 1.");
        }
    } else {
        cartItems.push(product);
        localStorage.setItem('cartItems1', JSON.stringify(cartItems));
        showNotification("Thêm vào giỏ hàng thành công!");
    }
});

			document.addEventListener('DOMContentLoaded', function() {
    const btnOpen = document.querySelector('.btn-open');
    const btnClose = document.querySelector('.btn-close');
    const chatContainer = document.querySelector('.chat-container');

    // Mở khung chat khi click vào nút "Chat Nhanh Với Chúng Tôi"
    btnOpen.addEventListener('click', function() {
        chatContainer.style.display = 'flex';
    });

    // Đóng khung chat khi click vào nút "Đóng"
    btnClose.addEventListener('click', function() {
        chatContainer.style.display = 'none';
    });
});

	//lướt lên
document.getElementById("scrollToTopBtn").addEventListener("click", function() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});

function toggleVideoForm() {
  var videoForm = document.getElementById('videoForm');
  if (videoForm.style.display === 'none' || videoForm.style.display === '') {
    videoForm.style.display = 'block';
  } else {
    closeVideoForm();
  }
}

function closeVideoForm() {
  var videoForm = document.getElementById('videoForm');
  var video = document.getElementById("uploadedVideo");
  video.pause();
  video.currentTime = 0;
  videoForm.style.display = 'none';
}

function previewVideo(event) {
  var video = document.getElementById("uploadedVideo");
  var file = event.target.files[0];
  if (file) {
    var videoSrc = URL.createObjectURL(file);
    var videoSource = document.getElementById("videoSource");
    videoSource.src = videoSrc;
    video.load();
  }
}

function playPause() {
  var video = document.getElementById("uploadedVideo");
  if (video.paused) {
    video.play();
  } else {
    video.pause();
  }
}

function skipForward() {
  var video = document.getElementById("uploadedVideo");
  video.currentTime += 10; // Tua về phía trước 10 giây
}

function skipBackward() {
  var video = document.getElementById("uploadedVideo");
  video.currentTime -= 10; // Tua về phía sau 10 giây
}

function adjustVolume() {
  var video = document.getElementById("uploadedVideo");
  var volume = document.getElementById("volumeRange").value;
  video.volume = volume;
}

// JavaScript cho kéo thả
dragElement(document.getElementById("videoForm"));

function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  if (elmnt.getElementsByClassName("draggable")[0]) {
    elmnt.getElementsByClassName("draggable")[0].onmousedown = dragMouseDown;
  } else {
    elmnt.onmousedown = dragMouseDown;
  }

  function dragMouseDown(e) {
    e = e || window.event;
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
  }

  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

//Thêm mới

// Hàm để thêm đánh giá vào danh sách
        function addReview(name, comment, file, rating) {
            const reviewsList = document.getElementById('reviewsList');
            const reviewItem = document.createElement('div');
            reviewItem.classList.add('review-item');
            
            let reviewContent = `<strong>Họ tên:</strong> ${name}<br>
                                 <strong>Bình luận:</strong> ${comment}<br>
                                 <strong>Đánh giá sao:</strong> ${'&#9733;'.repeat(rating)}${'&#9734;'.repeat(5 - rating)}`;

            if (file) {
                const fileURL = URL.createObjectURL(file);
                const fileType = file.type.split('/')[0];
                if (fileType === 'image') {
                    reviewContent += `<img src="${fileURL}" alt="Uploaded file">`;
                } else if (fileType === 'video') {
                    reviewContent += `<video controls><source src="${fileURL}" type="${file.type}"></video>`;
                } else if (fileType === 'audio') {
                    reviewContent += `<audio controls><source src="${fileURL}" type="${file.type}"></audio>`;
                }
            }

            reviewItem.innerHTML = reviewContent;
            reviewsList.appendChild(reviewItem);
        }

        // Xử lý sự kiện khi gửi đánh giá
        document.getElementById('reviewForm').addEventListener('submit', function(event) {
            event.preventDefault();
            
            const name = document.getElementById('name').value.trim();
            const comment = document.getElementById('comment').value.trim();
            const file = document.getElementById('fileUpload').files[0];
            const rating = document.querySelector('.rating span.active')?.dataset.value;

            if (name && comment && rating) {
                addReview(name, comment, file, parseInt(rating));
                alert('Đánh giá đã được gửi thành công!');
                this.reset();
                document.querySelectorAll('.rating span').forEach(span => span.classList.remove('active'));
            } else {
                alert('Vui lòng điền đầy đủ thông tin!');
            }
        });

        // Xử lý sự kiện khi chọn sao đánh giá
        document.getElementById('rating').addEventListener('mouseover', function(event) {
            if (event.target.dataset.value) {
                const value = parseInt(event.target.dataset.value);
                document.querySelectorAll('.rating span').forEach(span => {
                    span.classList.toggle('active', parseInt(span.dataset.value) <= value);
                });
            }
        });

        document.getElementById('rating').addEventListener('mouseout', function() {
            const activeRating = document.querySelector('.rating .active');
            const value = activeRating ? parseInt(activeRating.dataset.value) : 0;
            document.querySelectorAll('.rating span').forEach(span => {
                span.classList.toggle('active', parseInt(span.dataset.value) <= value);
            });
        });

        document.getElementById('rating').addEventListener('click', function(event) {
            if (event.target.dataset.value) {
                const value = parseInt(event.target.dataset.value);
                document.querySelectorAll('.rating span').forEach(span => {
                    span.classList.remove('active');
                });
                event.target.classList.add('active');
                event.target.previousSibling.classList.add('active');
            }
        });




