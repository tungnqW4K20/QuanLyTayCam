function smoothScroll(element, distance, duration) {
    const start = element.scrollLeft;
    const startTime = performance.now();

    function scrollStep(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1); // Tỉ lệ hoàn thành (từ 0 đến 1)

        // Hàm easeOutQuad để tạo hiệu ứng mượt mà
        const easeOutQuad = progress * (2 - progress);
        element.scrollLeft = start + distance * easeOutQuad;

        if (elapsed < duration) {
            window.requestAnimationFrame(scrollStep);
        }
    }

    window.requestAnimationFrame(scrollStep);
}

function slideLeft() {
    const slider = document.getElementById("slider");
    smoothScroll(slider, -600, 500); // Cuộn về bên trái 600px trong 500ms
    resetAutoSlide(); // Reset thời gian tự động cuộn
}

function slideRight() {
    const slider = document.getElementById("slider");
    smoothScroll(slider, 600, 500); // Cuộn về bên phải 600px trong 500ms
    resetAutoSlide(); // Reset thời gian tự động cuộn
}

function autoSlide() {
    const slider = document.getElementById("slider");
    smoothScroll(slider, 600, 500); // Tự động cuộn về bên phải
}

function resetAutoSlide() {
    clearInterval(autoSlideInterval); // Xóa bộ đếm thời gian hiện tại
    autoSlideInterval = setInterval(autoSlide, 3000); // Khởi động lại tự động cuộn sau mỗi 3 giây
}

// Khởi tạo tự động cuộn khi trang được tải
document.addEventListener("DOMContentLoaded", function () {
    autoSlideInterval = setInterval(autoSlide, 3000); // Tự động cuộn sau mỗi 3 giây
});
