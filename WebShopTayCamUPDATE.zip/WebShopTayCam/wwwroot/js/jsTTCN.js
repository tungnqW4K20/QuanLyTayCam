// Dữ liệu mẫu về đơn hàng của người dùng
//const orders = [
//    { id: 'DH001', date: '2024-09-15', total: '1.500.000 VND', status: 'Hoàn Thành', details: [
//        { product: 'Laptop', quantity: 1, price: '1.200.000 VND' },
//        { product: 'Chuột', quantity: 1, price: '300.000 VND' }
//    ]},
//    { id: 'DH002', date: '2024-09-20', total: '2.000.000 VND', status: 'Đang Giao', details: [
//        { product: 'Bàn Phím', quantity: 1, price: '1.500.000 VND' },
//        { product: 'Tai Nghe', quantity: 1, price: '500.000 VND' }
//    ]},
//    { id: 'DH003', date: '2024-09-25', total: '500.000 VND', status: 'Đã Hủy', details: [
//        { product: 'Cáp Sạc', quantity: 1, price: '500.000 VND' }
//    ]}
//];

// //Hiển thị các đơn hàng lên bảng lịch sử
//const orderTableBody = document.querySelector("#order-history tbody");

//orders.forEach(order => {
//    const row = document.createElement("tr");
    
//    row.innerHTML = `
//        <td><a href="#" class="order-link" data-id="${order.id}">${order.id}</a></td>
//        <td>${order.date}</td>
//        <td>${order.total}</td>
//        <td>${order.status}</td>
//    `;
    
//    orderTableBody.appendChild(row);
//});

// Chức năng hiển thị modal chi tiết đơn hàng
const modal = document.getElementById("order-details-modal");
const modalContent = document.getElementById("order-details-content");
const closeModalBtn = document.querySelector(".close");

//document.querySelectorAll(".order-link").forEach(link => {
//    link.addEventListener("click", (e) => {
//        e.preventDefault();
//        const orderId = link.getAttribute("data-id");
//        console.log(orderId);
      
//        // Gọi AJAX đến API để lấy chi tiết đơn hàng
//        $.ajax({
//            url: '/Home/ViewChiTietHoaDon', // Đường dẫn API
//            type: 'GET',
//            data: { id: orderId },
//            success: function (detailsHtml) {
//                // Hiển thị chi tiết đơn hàng trong modal
//                $('#order-details-content').html(detailsHtml);
//                $('#order-details-modal').show(); // Hiển thị modal
//            },
//            error: function (xhr, status, error) {
//                alert('Không thể lấy chi tiết đơn hàng. Vui lòng thử lại.');
//            }
//        });


//    });
//});


//function showOrderDetails(order) {
//    let detailsHTML = `<strong>Mã Đơn Hàng:</strong> ${order.id}<br>
//                       <strong>Ngày Mua:</strong> ${order.date}<br>
//                       <strong>Tổng Tiền:</strong> ${order.total}<br>
//                       <strong>Trạng Thái:</strong> ${order.status}<br><br>
//                       <strong>Chi Tiết Sản Phẩm:</strong><br>`;
    
//    order.details.forEach(item => {
//        detailsHTML += `Sản Phẩm: ${item.product}, Số Lượng: ${item.quantity}, Giá: ${item.price}<br>`;
//    });

//    modalContent.innerHTML = detailsHTML;
//    modal.style.display = "block";
//}



// Đóng modal khi nhấn vào nút "X"
closeModalBtn.addEventListener("click", () => {
    modal.style.display = "none";
});

// Đóng modal khi nhấn ra ngoài modal
window.addEventListener("click", (e) => {
    if (e.target == modal) {
        modal.style.display = "none";
    }
});

// Chức năng chỉnh sửa thông tin cá nhân
const editBtn = document.getElementById("edit-btn");
const saveBtn = document.getElementById("save-btn");
const cancelBtn = document.getElementById("cancel-btn");

editBtn.addEventListener("click", () => {
    document.querySelectorAll(".edit-field").forEach(field => {
        field.style.display = "block";
    });
    document.querySelectorAll(".info span").forEach(span => {
        span.style.display = "none";
    });
    editBtn.classList.add("hide");
    saveBtn.classList.remove("hide");
    cancelBtn.classList.remove("hide");
});

saveBtn.addEventListener("click", () => {
    const name = document.getElementById("name-input").value;
    const address = document.getElementById("address-input").value;
    const phone = document.getElementById("phone-input").value;
    const email = document.getElementById("email-input").value;

    console.log(name, address, phone, email);
    document.getElementById("name-display").textContent = name;
    document.getElementById("address-display").textContent = address;
    document.getElementById("phone-display").textContent = phone;
    document.getElementById("email-display").textContent = email;

    document.querySelectorAll(".edit-field").forEach(field => {
        field.style.display = "none";
    });
    document.querySelectorAll(".info span").forEach(span => {
        span.style.display = "block";
    });
    editBtn.classList.remove("hide");
    saveBtn.classList.add("hide");
    cancelBtn.classList.add("hide");

     // Tạo khách hàng
			const khachHangData = {
				MaKhachHang: "1",
                TenKH: name,
                SDTKH:  phone,
                Email: email,
                DiaChiKH:  address
			};

    $.ajax({
        url: '/Home/CreateKH',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(khachHangData),
         //data: JSON.stringify({
         ////	selectedProducts: selectedProducts,
         //	khachHangData: khachHangData
         //}),
        success: function (response) {
            if (response.success) {
                // Handle success scenario (e.g., show a message or reload)
                window.location.href = '/Home/IndexTTCN';
            }
        },
        error: function (error) {
            console.log('Error occurred:', error);
        }
    });
});

cancelBtn.addEventListener("click", () => {
    document.querySelectorAll(".edit-field").forEach(field => {
        field.style.display = "none";
    });
    document.querySelectorAll(".info span").forEach(span => {
        span.style.display = "block";
    });
    editBtn.classList.remove("hide");
    saveBtn.classList.add("hide");
    cancelBtn.classList.add("hide");
});
