﻿namespace WebShopTayCam.Models
{
    public class BinhLuanModel
    {
        public int MaBinhLuan { get; set; }
        public int MaKhachHang { get; set; }
        public int MaSanPham { get; set; }
        public string NoiDung { get; set; }
        public string TenKhachHang { get; set; }
        public int TrangThai { get; set; }

    }
}
