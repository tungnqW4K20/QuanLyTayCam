﻿namespace WebShopTayCam.Models
{
	public class GioHangModel
	{
		public int MaSanPham { get; set; }
		public int SoLuong { get; set; }
		public decimal Gia { get; set; }

		public int MaKhachHang { get; set; }

		public string TenKH { get; set; }
		public string SDTKH { get; set; }

		public string Email { get; set; }
		public string DiaChiKH { get; set; }

	}
}
