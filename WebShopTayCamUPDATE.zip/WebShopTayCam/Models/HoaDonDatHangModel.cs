﻿namespace WebShopTayCam.Models
{
    public class HoaDonDatHangModel
    { 
        public int MaHoaDon { get; set; }
        public string NgayDat { get; set; }

        public decimal TongTien { get; set; }

        public string TrangThai { get; set; }


    }
}
