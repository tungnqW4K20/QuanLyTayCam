﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace WebShopTayCam.Models
{

        public class KhachHangTaiKhoanModel
        {
            public int MaKhachHang { get; set; } // Thường là khóa chính, tự tăng, không cần nhập khi đăng ký

            [Required(ErrorMessage = "Vui lòng nhập Tên Khách Hàng.")]
            [Display(Name = "Họ và Tên")]
            [StringLength(100, ErrorMessage = "Tên Khách Hàng không được vượt quá 100 ký tự.")]
            public string TenKH { get; set; }

            [Required(ErrorMessage = "Vui lòng nhập Số Điện Thoại.")]
            [Display(Name = "Số Điện Thoại")]
            [Phone(ErrorMessage = "Số Điện Thoại không hợp lệ.")]
            [StringLength(15, MinimumLength = 9, ErrorMessage = "Số Điện Thoại phải từ 9 đến 15 chữ số.")]
            public string SDTKH { get; set; }

            [Required(ErrorMessage = "Vui lòng nhập Email.")]
            [EmailAddress(ErrorMessage = "Địa chỉ Email không hợp lệ.")]
            [Display(Name = "Email")]
            [StringLength(100, ErrorMessage = "Email không được vượt quá 100 ký tự.")]
            public string Email { get; set; }

            [Required(ErrorMessage = "Vui lòng nhập Địa Chỉ.")]
            [Display(Name = "Địa Chỉ Giao Hàng")]
            [StringLength(250, ErrorMessage = "Địa chỉ không được vượt quá 250 ký tự.")]
            public string DiaChiKH { get; set; }

            [Required(ErrorMessage = "Vui lòng nhập Tên Tài Khoản.")]
            [Display(Name = "Tên Tài Khoản")]
            [StringLength(50, MinimumLength = 5, ErrorMessage = "Tên Tài Khoản phải từ 5 đến 50 ký tự.")]
            // Thêm kiểm tra xem tài khoản đã tồn tại chưa (trong Controller)
            public string TaiKhoan { get; set; }

            [Required(ErrorMessage = "Vui lòng nhập Mật Khẩu.")]
            [Display(Name = "Mật Khẩu")]
            [DataType(DataType.Password)]
            [StringLength(100, MinimumLength = 6, ErrorMessage = "Mật khẩu phải có ít nhất 6 ký tự.")]
            public string MatKhau { get; set; }

          
        
    }
}
