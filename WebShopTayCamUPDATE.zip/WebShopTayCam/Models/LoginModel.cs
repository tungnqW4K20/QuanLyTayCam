﻿namespace WebShopTayCam.Models
{
	public class LoginModel
	{

		public string UserName { get; set; }
		public string MK { get; set; }


	}
}
