﻿namespace WebShopTayCam.Models
{
	public class HoaDonKhachHangModel
	{

		public string TenKH { get; set; }
		public string DiaChiKH { get; set; }
		public string NgayLap { get; set; }

		public string HinhAnh { get; set; }
		public string TenSanPham { get; set; }
		public string SoLuong { get; set; }
		public string DonGia { get; set; }

		public string ThanhTien { get; set; }



	}
}
