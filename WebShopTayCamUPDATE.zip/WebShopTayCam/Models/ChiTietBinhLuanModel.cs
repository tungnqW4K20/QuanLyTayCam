﻿namespace WebShopTayCam.Models
{
    public class ChiTietBinhLuanModel
    {
        public int ID { get; set; }
        public int ID_BinhLuan { get; set; }
        public string NoiDung { get; set; }
        public int DoiTuongBinhLuan { get; set; }
        public DateTime NgayBinhLuan { get; set; }
        public string TenKhachHang { get; set; }

    }
}
