﻿namespace WebShopTayCam.Models
{
	public class GioHangKH
	{
		public int MaGH { get; set; }
		public int MaSanPham { get; set; }
		public int MaKhachHang { get; set; }
		public string TenSanPham { get; set; }
		public int SoLuongThem { get; set; }
		public decimal DonGia { get; set; }
		public string HinhAnh { get; set; }
		public decimal ThanhTien => DonGia * SoLuongThem;
	}
}
