﻿namespace WebShopTayCam.Models
{
    public class BinhLuanViewModel
    {
        public List<BinhLuanTenSPModel> BinhLuans { get; set; }
        public List<ChiTietBinhLuanModel> ChiTietBinhLuans { get; set; }
    }
}
