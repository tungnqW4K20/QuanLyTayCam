﻿namespace WebShopTayCam.Models
{
	public class GioHang
	{
		public int MaSanPham { get; set; }
		public string TenSanPham { get; set; }
		public decimal Gia { get; set; }
		public string HinhAnh { get; set; }
		public int SoLuong { get; set; }
		public decimal ThanhTien => SoLuong * Gia;
	}
}
