﻿namespace WebShopTayCam.Models
{
	public class SanPhamModel
	{

		public int MaSanPham { get; set; }
		public Nullable<int> MaDanhMuc { get; set; }
		public string TenSanPham { get; set; }
		public string NoiDung { get; set; }
		public Nullable<decimal> Gia { get; set; }
		public string HinhAnh { get; set; }
		public Nullable<bool> SanPhamTop { get; set; }
		public Nullable<bool> SanPhamUuDai { get; set; }


	}
}
