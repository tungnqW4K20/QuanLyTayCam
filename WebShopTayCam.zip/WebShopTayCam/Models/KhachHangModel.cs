﻿namespace WebShopTayCam.Models
{
	public class KhachHangModel
	{
		public int MaKhachHang { get; set; }

		public string TenKH { get; set; }
		public string SDTKH { get; set; }

		public string Email { get; set; }
		public string DiaChiKH { get; set; }
	}
}
