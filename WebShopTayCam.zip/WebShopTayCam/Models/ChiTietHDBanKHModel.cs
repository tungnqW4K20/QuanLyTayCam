﻿namespace WebShopTayCam.Models
{
    public class ChiTietHDBanKHModel
    {


        public string MaHoaDonBan { get; set; }
        public string NgayBan { get; set; }
        public string TrangThai { get; set; }
        public string TenSanPham { get; set; }
        public decimal TongTien { get; set; }

        public int SoLuongBan { get; set; }
        public decimal DonGiaBan { get; set; }
    }
}
