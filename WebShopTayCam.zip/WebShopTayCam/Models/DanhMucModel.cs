﻿namespace WebShopTayCam.Models
{
	public class DanhMucModel
	{
		public int MaDanhMuc { get; set; }
		public string TenDanhMuc { get; set; }
	}
}
