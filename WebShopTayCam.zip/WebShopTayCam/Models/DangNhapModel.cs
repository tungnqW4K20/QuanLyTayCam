﻿namespace WebShopTayCam.Models
{
	public class DangNhapModel
	{
		public int MaTK { get; set; }

		public string TenTK { get; set; }
		public string MK { get; set; }

		public int MaKhachHang { get; set; }


	}
}
