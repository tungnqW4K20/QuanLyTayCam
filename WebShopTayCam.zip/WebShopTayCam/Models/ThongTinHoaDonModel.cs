﻿namespace WebShopTayCam.Models
{
	public class ThongTinHoaDonMoDel
	{

		public int MaSanPham { get; set; }
		public string UserNameKH { get; set; }


		public int SoLuongBan { get; set; }

		public decimal DonGiaBan { get; set; }

	}
}
