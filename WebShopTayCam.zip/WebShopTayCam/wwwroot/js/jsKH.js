// Danh sách khách hàng giả lập
const customers = [
    { id: 'KH001', name: 'Nguyễn Văn A', address: '123 Đường ABC, TP.HCM', phone: '0123456789', email: 'a.nguyen@example.com' },
    { id: 'KH002', name: 'Trần Thị B', address: '456 Đường XYZ, Hà Nội', phone: '0987654321', email: 'b.tran@example.com' },
    { id: 'KH003', name: 'Lê Văn C', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'c.le@example.com' },
    // Thêm nhiều khách hàng giả lập vào đây (ít nhất 15 khách hàng)
    { id: 'KH004', name: 'Phạm Văn D', address: '123 Đường ABC, TP.HCM', phone: '0123456789', email: 'd.pham@example.com' },
    { id: 'KH005', name: 'Trần Quốc E', address: '456 Đường XYZ, Hà Nội', phone: '0987654321', email: 'e.tran@example.com' },
    { id: 'KH006', name: 'Hoàng Thị F', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'f.hoang@example.com' },
    { id: 'KH007', name: 'Nguyễn Văn G', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'g.nguyen@example.com' },
    { id: 'KH008', name: 'Lê Văn H', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'h.le@example.com' },
    { id: 'KH009', name: 'Nguyễn Văn I', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'i.nguyen@example.com' },
    { id: 'KH010', name: 'Trần Văn J', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'j.tran@example.com' },
    { id: 'KH011', name: 'Lê Thị K', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'k.le@example.com' },
    { id: 'KH012', name: 'Hoàng Văn L', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'l.hoang@example.com' },
    { id: 'KH013', name: 'Trần Văn M', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'm.tran@example.com' },
    { id: 'KH014', name: 'Nguyễn Thị N', address: '789 Đường LMN, Đà Nẵng', phone: '0111222333', email: 'n.nguyen@example.com' }
];

const rowsPerPage = 12;
let currentPage = 1;

function renderTable(page) {
    const startIndex = (page - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    const visibleCustomers = customers.slice(startIndex, endIndex);

    const tableBody = document.getElementById('customer-table-body');
    tableBody.innerHTML = '';

    visibleCustomers.forEach(customer => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${customer.id}</td>
            <td>${customer.name}</td>
            <td>${customer.address}</td>
            <td>${customer.phone}</td>
            <td>${customer.email}</td>
            <td><button class="view-history-btn">Xem lịch sử mua hàng</button></td>
        `;
        tableBody.appendChild(row);
    });

    document.getElementById('page-info').innerText = `Trang ${page} / ${Math.ceil(customers.length / rowsPerPage)}`;

    document.getElementById('prev-btn').disabled = page === 1;
    document.getElementById('next-btn').disabled = page === Math.ceil(customers.length / rowsPerPage);
}

document.getElementById('prev-btn').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        renderTable(currentPage);
    }
});

document.getElementById('next-btn').addEventListener('click', () => {
    if (currentPage < Math.ceil(customers.length / rowsPerPage)) {
        currentPage++;
        renderTable(currentPage);
    }
});

renderTable(currentPage);




// Giả lập lịch sử giao dịch cho mỗi khách hàng
const transactionHistory = {
    'KH001': [
        { orderId: 'DH001', product: 'Sản phẩm A', quantity: 2, date: '2024-01-15', total: '500,000 VND' },
        { orderId: 'DH002', product: 'Sản phẩm B', quantity: 1, date: '2024-02-03', total: '300,000 VND' },
    ],
    'KH002': [
        { orderId: 'DH003', product: 'Sản phẩm C', quantity: 3, date: '2024-03-21', total: '900,000 VND' },
        { orderId: 'DH004', product: 'Sản phẩm D', quantity: 1, date: '2024-04-12', total: '450,000 VND' },
    ],
    // Thêm nhiều lịch sử giao dịch cho các khách hàng khác
};

// Hiển thị lịch sử mua hàng
document.querySelectorAll('.view-history-btn').forEach((btn, index) => {
    btn.addEventListener('click', () => {
        const customerId = customers[index].id;
        const customerName = customers[index].name;
        const history = transactionHistory[customerId] || [];

        // Hiển thị tên khách hàng
        document.getElementById('customer-name').innerText = customerName;

        // Tạo nội dung bảng lịch sử giao dịch
        const historyBody = document.getElementById('history-body');
        historyBody.innerHTML = ''; // Xóa nội dung cũ
        history.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.orderId}</td>
                <td>${item.product}</td>
                <td>${item.quantity}</td>
                <td>${item.date}</td>
                <td>${item.total}</td>
            `;
            historyBody.appendChild(row);
        });

        // Hiển thị modal
        document.getElementById('history-modal').style.display = 'flex';
    });
});

// Đóng modal khi nhấn nút X
document.querySelector('.close-btn').addEventListener('click', () => {
    document.getElementById('history-modal').style.display = 'none';
});

// Đóng modal khi nhấn ngoài modal
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        document.getElementById('history-modal').style.display = 'none';
    }
});
