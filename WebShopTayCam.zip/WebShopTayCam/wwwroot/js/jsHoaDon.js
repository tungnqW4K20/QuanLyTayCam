window.onload = function () {
    const today = new Date();
    const date = today.getDate() + '/' + (today.getMonth() + 1) + '/' + today.getFullYear();
    document.getElementById('invoice-date').innerText = date;
};

function changeQuantity(button, change) {
    const input = button.parentElement.querySelector('input[type="number"]');
    let quantity = parseInt(input.value) + change;
    if (quantity < 1) quantity = 1; // Đảm bảo số lượng không nhỏ hơn 1
    input.value = quantity;
    updateSummary();
}

function updateSummary() {
    const rows = document.querySelectorAll('.invoice-items tbody tr');
    let subtotal = 0;

    rows.forEach(row => {
        const quantity = parseInt(row.querySelector('input[type="number"]').value);
        const priceText = row.cells[3].innerText.replace('đ', '').replace('.', '').trim(); // Loại bỏ 'đ' và dấu chấm
        const price = parseInt(priceText);
        const totalPrice = quantity * price;
        row.cells[4].innerText = totalPrice.toLocaleString() + 'đ'; // Cập nhật thành tiền
        subtotal += totalPrice;
    });

    const tax = subtotal * 0.1; // Giả sử thuế là 10%
    const total = subtotal + tax;

    document.getElementById('subtotal').innerText = subtotal.toLocaleString() + 'đ';
    document.getElementById('tax').innerText = tax.toLocaleString() + 'đ';
    document.getElementById('total').innerText = total.toLocaleString() + 'đ';
}

function printInvoice() {
    window.print();
}