document.addEventListener('DOMContentLoaded', function () {
    const cartItems = JSON.parse(localStorage.getItem('cartItems1')) || [];
    const cartItemsContainer = document.querySelector('.cart-items');
    const totalPriceElement = document.getElementById('totalPrice');
    const totalPriceElementnew = document.getElementById('totalPrice1');
    const newCartItemsContainer = document.querySelector('.cart-items1');
    const cartItemCountElement = document.getElementById('cartItemCount');
    let totalPrice = 0;
    let newCart = [];
    let totalPrice1 = 0;

    function calculateTotalItemCount(cartItems) {
        return cartItems.reduce((total, item) => total + item.quantity, 0);
    }

    function updateCart() {
        cartItemsContainer.innerHTML = '';
        totalPrice = 0;

        cartItems.forEach((item, index) => {
            const itemElement = document.createElement('li');
            itemElement.classList.add('cart-item');

            itemElement.innerHTML = `
                <div class="checkbox-container">
                    <label for="checkbox-${index}"></label>
                </div>
                <img src="${item.image}" alt="${item.name}" onclick="navigateToProductDetail('${item.id}')">
                <div class="item-info">
                    <h4>${item.name}</h4>
                    <p class="item-price">${item.price.toLocaleString()} VND</p>
                    <div class="item-quantity">
                        <button class="update-btn decrease-btn" onclick="decreaseQuantity(${index})">-</button>
                        <input type="number" class="item-quantity" id="quantity-${index}" value="${item.quantity}" min="1" onchange="updateQuantity(${index}, this.value)">
                        <button class="update-btn increase-btn" onclick="increaseQuantity(${index})">+</button>
                    </div>
                </div>
                <button class="remove-btn" onclick="removeItem(${index})" style="font-weight: bold; margin-right: 70px; background-color: #ff5733">&#128465;</button>
                <input type="checkbox" id="checkbox-${index}" class="item-checkbox" onchange="toggleCheckbox(${index}, this.checked)">
            `;

            cartItemsContainer.appendChild(itemElement);
            totalPrice += item.price * item.quantity;
        });

        totalPriceElement.textContent = `${totalPrice.toLocaleString()} VND`;
        cartItemCountElement.textContent = calculateTotalItemCount(cartItems); // Cập nhật số lượng sản phẩm trong giỏ hàng
    }

    window.toggleCheckbox = function(index, isChecked) {
        const item = cartItems[index];
        if (isChecked) {
            newCart.push(item);
        } else {
            newCart = newCart.filter(cartItem => cartItem !== item);
        }
        updateNewCart();
    }

    function updateNewCart() {
        newCartItemsContainer.innerHTML = '';
        totalPrice1 = 0;

        newCart.forEach((item, index) => {
            const itemElement = document.createElement('li');
            itemElement.classList.add('cart-item');

            itemElement.innerHTML = `
                <img src="${item.image}" alt="${item.name}" onclick="navigateToProductDetail('${item.id}')">
                <div class="item-info">
                    <h4>${item.name}</h4>
                    <p class="item-price">${item.price.toLocaleString()} VND</p>
                    <div class="item-quantity">
                        <input type="number" class="item-quantity" id="new-quantity-${index}" value="${item.quantity}" min="1" readonly>
                    </div>
                </div>
            `;

            newCartItemsContainer.appendChild(itemElement);
            totalPrice1 += item.price * item.quantity;
        });

        totalPriceElementnew.textContent = `${totalPrice1.toLocaleString()} VND`;
    }

    window.decreaseQuantity = function (index) {
        if (cartItems[index].quantity > 1) {
            cartItems[index].quantity--;
            localStorage.setItem('cartItems1', JSON.stringify(cartItems));
            updateCart();
        }
    }

    window.increaseQuantity = function (index) {
        cartItems[index].quantity++;
        localStorage.setItem('cartItems1', JSON.stringify(cartItems));
        updateCart();
    }

    window.removeItem = function (index) {
        cartItems.splice(index, 1);
        localStorage.setItem('cartItems1', JSON.stringify(cartItems));
        updateCart();
    }

    window.updateQuantity = function (index, quantity) {
        if (quantity < 1) {
            quantity = 1;
        }
        cartItems[index].quantity = parseInt(quantity);
        localStorage.setItem('cartItems1', JSON.stringify(cartItems));
        updateCart();
    }

    window.navigateToProductDetail = function (productId) {
        window.location.href = 'indexCTSP.html?id=' + productId;
    }

    document.getElementById('customerInfo').addEventListener('submit', function (event) {
        event.preventDefault();

        alert('Đặt hàng thành công!');

        const deliveryOption = document.getElementById('deliveryOption').value;
        if (deliveryOption === 'store') {
            alert('Vui lòng đến cửa hàng để nhận hàng.');
        } else {
            alert('Hàng sẽ được giao đến địa chỉ của bạn.');
        }

        localStorage.removeItem('cartItems1');
        updateCart();
    });

    updateCart();
});

document.addEventListener('DOMContentLoaded', function () {
    const btnOpen = document.querySelector('.btn-open');
    const btnClose = document.querySelector('.btn-close');
    const chatContainer = document.querySelector('.chat-container');

    btnOpen.addEventListener('click', function () {
        chatContainer.style.display = 'flex';
    });

    btnClose.addEventListener('click', function () {
        chatContainer.style.display = 'none';
    });
});

document.getElementById("scrollToTopBtn").addEventListener("click", function() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});
