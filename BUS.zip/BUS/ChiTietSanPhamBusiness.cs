﻿using BUS.Interfaces;
using DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace BUS
{
	public partial class ChiTietSanPhamBusiness : IChiTietSanPhamBusiness
	{
		private IChiTietSanPhamRepository _res;
		public ChiTietSanPhamBusiness(IChiTietSanPhamRepository res)
		{
			_res = res;
		}
		public bool Create(	ChiTietSanPhamModel model)
		{
			return _res.Create(model);
		}

		public bool Update(ChiTietSanPhamModel model)
		{
			return _res.Update(model);
		}

		public bool Delete(string id)
		{
			return _res.Delete(id);
		}

		
		public List<ChiTietSanPhamModel1> GetAllByID(int id)
		{
			return (_res.GetAllByID(id));
		}
	}
}
