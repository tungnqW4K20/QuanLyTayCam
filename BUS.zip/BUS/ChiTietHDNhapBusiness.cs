﻿using BUS.Interfaces;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public partial class ChiTietHDNhapBusiness : IChiTietHDNhapBusiness
    {
        private IChiTietHoaDonNhapADMINReponsitory _res;
        public ChiTietHDNhapBusiness(IChiTietHoaDonNhapADMINReponsitory res)
        {
            _res = res;
        }
        public bool Create(HoaDonNhapADMINModel model)
        {
            return _res.Create(model);
        }

        public bool Update(HoaDonNhapADMINModel model)
        {
            return _res.Update(model);
        }

        public bool Delete(string id)
        {
            return _res.Delete(id);
        }

        public List<HoaDonNhapADModel> GetAll()
        {
            return _res.GetAll();
        }

        public List<ThongKeDoanhThu> GetAllDT()
        {
            return _res.GetAllDT();
        }


        public List<HoaDonNhapADMINModel> GetAllByID(int id)
        {
            return (_res.GetAllByID(id));
        }

    
    }
}
