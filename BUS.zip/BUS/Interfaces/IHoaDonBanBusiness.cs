﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;


namespace BUS.Interfaces
{
	public partial interface  IHoaDonBanBusiness
	{
		bool Create(HoaDonBanModel model);
		bool Update(HoaDonBanModel model);
		bool Delete(string id);
		List<HoaDonBanModel> GetAll();
        List<HoaDonBanTTModel> GetAllTT();
        List<HoaDonBanModel> GetAllByID(int id);

        List<HoaDonDatHangModel> GetAllByIDtheouser(string id);
        List<HoaDonKhachHangModel> GetAllHDMax();

	}
}
