﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace BUS.Interfaces
{
	public partial interface  IChiTietHoaDonBanBusiness
	{
		bool Create(ChiTietHoaDonBanModel model);
		bool Update(ChiTietHoaDonBanModel model);
		bool Delete(string id);
		List<ChiTietHoaDonBanModel> GetAll();


		List<ChiTietHoaDonBanModel> GetAllByID(int id);

        List<CHiTietHDBanKHModel> GetAllByIDtheoMaHD(int id);
        bool ThemHoaDon(List<ThongTinHoaDonMoDel> model);

	}
}
