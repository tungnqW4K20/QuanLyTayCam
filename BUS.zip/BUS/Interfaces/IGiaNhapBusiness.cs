﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS.Interfaces
{
	public partial interface IGiaNhapBusiness 
	{ 
		bool Create(GiaNhapModel model);
		bool Update(GiaNhapModel model);
		bool Delete(string id);
		List<GiaNhapModel> GetAll();
		
		List<GiaNhapModel> GetAllByID(int id);


	}
}
