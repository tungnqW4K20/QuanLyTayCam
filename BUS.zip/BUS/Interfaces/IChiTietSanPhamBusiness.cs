﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace BUS.Interfaces
{
	public partial interface IChiTietSanPhamBusiness
	{
		bool Create(ChiTietSanPhamModel model);
		bool Update(ChiTietSanPhamModel model);
		bool Delete(string id);
		
		List<ChiTietSanPhamModel1> GetAllByID(int id);


	}
}
