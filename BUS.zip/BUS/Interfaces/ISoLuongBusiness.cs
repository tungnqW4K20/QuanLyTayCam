﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS.Interfaces
{
	public partial interface ISoLuongBusiness
	{
		bool Create(SoLuongModel model);
		bool Update(SoLuongModel model);
		bool Delete(string id);
		List<SoLuongModel> GetAll();
		List<SoLuongModel> GetAllTop();
		List<SoLuongModel> GetAllByID(int id);


	}
}
