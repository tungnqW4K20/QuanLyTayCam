﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS.Interfaces
{
	public partial interface IKhachHangBusiness
	{
		bool Create(KhachHangModel model);
		bool Update(KhachHangModel model);

        bool Updatetheouser(KhachHangModel2 model);
        bool Delete(string id);
		List<KhachHangModel> GetAll();
		
		List<KhachHangModel> GetAllByID(int id);

		List<KhachHangModel> GetAllByIDtheoUser(string id);

	}
}
