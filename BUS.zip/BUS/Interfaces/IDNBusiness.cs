﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS.Interfaces
{
	public partial interface IDNBusiness
	{
		bool Create(DangNhapModel model);
		bool Update(DangNhapModel model);
		bool Delete(string id);
		List<DangNhapModel> GetAll();
		List<DangNhapModel> GetAllTop();
		List<DangNhapModel> GetAllByID(int id);


	}
}
