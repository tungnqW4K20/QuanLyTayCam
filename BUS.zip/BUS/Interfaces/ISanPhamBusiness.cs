﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS.Interfaces
{
    public partial interface ISanPhamBusiness
    {
        bool Create(SanPhamModel model);
        bool Update(SanPhamModel model);
        bool Delete(string id);
        List<SanPhamModel> GetAll();

        List<SanPhamADMINModel> GetAllADMIN();
        List<SanPhamADMINModel> GetAllADMINHetHang();
        List<SanPhamModel> GetAllTop();
		List<SanPhamModel> GetAllByID(int id);

        List<SanPhamModel> GetAllByIDDM(int id);

        List<SanPhamModel> GetAllByTenM(string id);


    }
}
