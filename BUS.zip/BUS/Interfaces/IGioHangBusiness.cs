﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
namespace BUS.Interfaces
{
	public partial interface IGioHangBusiness
	{
		bool Create(GioHangModel model);
		bool Update(GioHangModel model);
		bool Delete(string id,string UserID);
		List<GioHangModel> GetAll();
		List<GioHangModel> GetAllTop();
		List<GioHangKH1> GetAllByID(string id);
		List<GioHangKH1> TangGH(string id, string UserID);
		List<GioHangKH1> GiamGH(string id, string UserID);

		List<GioHangKH1> ThemGH(string id, string UserID);



	}
}
