﻿using BUS.Interfaces;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
	public partial class GioHangBusiness : IGioHangBusiness
	{
		private IGioHangRepository _res;
		public GioHangBusiness(IGioHangRepository res)
		{
			_res = res;
		}
		public bool Create(GioHangModel model)
		{
			return _res.Create(model);
		}

		public bool Update(GioHangModel model)
		{
			return _res.Update(model);
		}

		public bool Delete(string id,string UserID)
		{
			return _res.Delete(id, UserID);
		}

		public List<GioHangModel> GetAll()
		{
			return _res.GetAll();
		}

		public List<GioHangModel> GetAllTop()
		{
			return _res.GetAllTop();
		}
		public List<GioHangKH1> GetAllByID(string id)
		{
			return (_res.GetAllByID(id));
		}

		public List<GioHangKH1> TangGH(string id,string UserID)
		{
			return _res.TangGH(id, UserID);
		}
		public List<GioHangKH1> GiamGH(string id, string UserID)
		{
			return (_res.GiamGH(id,UserID));
		}

		public List<GioHangKH1> ThemGH(string id, string UserID)
		{
			return (_res.ThemGH(id, UserID));
		}
		
	}
}


