﻿using BUS.Interfaces;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
	public partial class ChiTietHoaDonBanBusiness : IChiTietHoaDonBanBusiness
	{
		private IChiTietHoaDonBanReponsitory _res;
		public ChiTietHoaDonBanBusiness(IChiTietHoaDonBanReponsitory res)
		{
			_res = res;
		}
		public bool Create(ChiTietHoaDonBanModel model)
		{
			return _res.Create(model);
		}

		public bool Update(ChiTietHoaDonBanModel model)
		{
			return _res.Update(model);
		}

		public bool Delete(string id)
		{
			return _res.Delete(id);
		}

		public List<ChiTietHoaDonBanModel> GetAll()
		{
			return _res.GetAll();
		}

	
		public List<ChiTietHoaDonBanModel> GetAllByID(int id)
		{
			return (_res.GetAllByID(id));
		}

        public List<CHiTietHDBanKHModel> GetAllByIDtheoMaHD(int id)
        {
            return (_res.GetAllByIDTheoMaHD(id));
        }
        public bool ThemHoaDon(List<ThongTinHoaDonMoDel> model)
		{
			return _res.ThemHoaDon(model);
		}

	}
}
