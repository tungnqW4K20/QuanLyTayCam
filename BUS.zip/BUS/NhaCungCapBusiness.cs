﻿using BUS.Interfaces;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public partial class NhaCungCapBusiness : INhaCungCapBusiness
    {
        private INhaCungCapReponsitory _res;
        public NhaCungCapBusiness(INhaCungCapReponsitory res)
        {
            _res = res;
        }
        public bool Create(NhaCungCapModel model)
        {
            return _res.Create(model);
        }

        public bool Update(NhaCungCapModel model)
        {
            return _res.Update(model);
        }

        public bool Delete(string id)
        {
            return _res.Delete(id);
        }

        public List<NhaCungCapModel> GetAll()
        {
            return _res.GetAll();
        }

       
        public List<NhaCungCapModel> GetAllByID(int id)
        {
            return (_res.GetAllByID(id));
        }

        public List<NhaCungCapModel> GetAllByTenM(string id)
        {
            return (_res.GetAllByTenM(id));
        }
    }
}





