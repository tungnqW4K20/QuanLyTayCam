﻿using BUS.Interfaces;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public partial class DanhMucBusiness : IDanhMucBusiness
    {
        private IDanhMucRepository _res;
        public DanhMucBusiness(IDanhMucRepository res)
        {
            _res = res;
        }
        public bool Create(DanhMucModel model)
        {
            return _res.Create(model);
        }

        public bool Update(DanhMucModel model)
        {
            return _res.Update(model);
        }

        public bool Delete(DanhMucModel model)
        {
            return _res.Delete(model);
        }


        public List<DanhMucModel> GetAll()
        {
            return _res.GetAll();
        }

    }
}
