﻿using BUS.Interfaces;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
	public partial class HoaDonBanBusiness : IHoaDonBanBusiness
	{
		private IHoaDonBanReponsitory _res;
		public HoaDonBanBusiness(IHoaDonBanReponsitory res)
		{
			_res = res;
		}
		public bool Create(HoaDonBanModel model)
		{
			return _res.Create(model);
		}

		public bool Update(HoaDonBanModel model)
		{
			return _res.Update(model);
		}

		public bool Delete(string id)
		{
			return _res.Delete(id);
		}

		public List<HoaDonBanModel> GetAll()
		{
			return _res.GetAll();
		}

        public List<HoaDonBanTTModel> GetAllTT()
        {
            return _res.GetAllTT();
        }

        public List<HoaDonKhachHangModel> GetAllHDMax()
		{
			return _res.GetAllHDMax();
		}

		public List<HoaDonBanModel> GetAllByID(int id)
		{
			return (_res.GetAllByID(id));
		}

        public List<HoaDonDatHangModel> GetAllByIDtheouser(string id)
        {
            return (_res.GetAllByIDtheoUser(id));
        }


    }
}
