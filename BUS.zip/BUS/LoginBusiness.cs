﻿using BUS.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Interfaces;
using Model;
namespace BUS
{
	public partial class LoginBusiness : ILoginBusiness
	{
		private ILoginRepository _res;
		public LoginBusiness(ILoginRepository res)
		{
			_res = res;
		}
		public bool Loginstring(LoginModel model)
		{
			return _res.Loginstring(model);
		}


	}
}
