﻿using BUS.Interfaces;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public partial class SanPhamBusiness : ISanPhamBusiness
    {
        private ISanPhamRepository _res;
        public SanPhamBusiness(ISanPhamRepository res)
        {
            _res = res;
        }
        public bool Create(SanPhamModel model)
        {
            return _res.Create(model);
        }

        public bool Update(SanPhamModel model)
        {
            return _res.Update(model);
        }

        public bool Delete(string id)
        {
            return _res.Delete(id);
        }

        public List<SanPhamModel> GetAll()
        {
            return _res.GetAll();
        }

        public List<SanPhamADMINModel> GetAllADMIN()
        {
            return _res.GetAllADMIN();
        }

        public List<SanPhamADMINModel> GetAllADMINHetHang()
        {
            return _res.GetAllADMINHetHang();
        }


        public List<SanPhamModel> GetAllTop()
		{
			return _res.GetAllTop();
		}
		public List<SanPhamModel> GetAllByID(int id)
        {
            return (_res.GetAllByID(id));
        }

        public List<SanPhamModel> GetAllByIDDM(int id)
        {
            return (_res.GetAllByIDDM(id));
        }

        public List<SanPhamModel> GetAllByTenM(string id)
        {
            return (_res.GetAllByTenM(id));
        }
    }
}
