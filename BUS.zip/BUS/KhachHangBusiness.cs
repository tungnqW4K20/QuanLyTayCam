﻿using BUS.Interfaces;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
	public partial class KhachHangBusiness : IKhachHangBusiness
	{
		private IKhachHangReponsitory _res;
		public KhachHangBusiness(IKhachHangReponsitory res)
		{
			_res = res;
		}
		public bool Create(KhachHangModel model)
		{
			return _res.Create(model);
		}

		public bool Update(KhachHangModel model)
		{
			return _res.Update(model);
		}

        public bool Updatetheouser(KhachHangModel2 model)
        {
            return _res.Updatetheouser(model);
        }

        public bool Delete(string id)
		{
			return _res.Delete(id);
		}

		public List<KhachHangModel> GetAll()
		{
			return _res.GetAll();
		}

		
		public List<KhachHangModel> GetAllByID(int id)
		{
			return (_res.GetAllByID(id));
		}

		public List<KhachHangModel> GetAllByIDtheoUser(string id)
		{
			return (_res.GetAllByIDtheoUser(id));


		}
	}
}
