﻿using BUS.Interfaces;
using DAL.Interfaces;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
	public partial class SoLuongBusiness : ISoLuongBusiness
	{
		private ISoLuongRepository _res;
		public SoLuongBusiness(ISoLuongRepository res)
		{
			_res = res;
		}
		public bool Create(SoLuongModel model)
		{
			return _res.Create(model);
		}

		public bool Update(SoLuongModel model)
		{
			return _res.Update(model);
		}

		public bool Delete(string id)
		{
			return _res.Delete(id);
		}

		public List<SoLuongModel> GetAll()
		{
			return _res.GetAll();
		}

		public List<SoLuongModel> GetAllTop()
		{
			return _res.GetAllTop();
		}
		public List<SoLuongModel> GetAllByID(int id)
		{
			return (_res.GetAllByID(id));
		}
	}
}
