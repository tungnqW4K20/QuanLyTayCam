﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplicationADMIN.Models;
using System;
using System.IO;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Hosting;
using NuGet.Common;
using NuGet.Protocol.Plugins;

namespace WebApplicationADMIN.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;


        private readonly HttpClient _httpClient;

        public HomeController(ILogger<HomeController> logger, HttpClient httpClient)
        {
            _logger = logger;
            _httpClient = httpClient;
        }

        public async Task<IActionResult> Index()
        {

            //// URL của API
          //  string apiUrl = "https://localhost:7268/api/SanPham/getalltop-item";
            string apiUrl = "https://localhost:7268/api/KhachHang/getall-item";

            try
            {
                // Gửi yêu cầu đến API
                HttpResponseMessage response = await _httpClient.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc dữ liệu JSON từ API
                    string jsonData = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách khách hàng
                    var customers = JsonConvert.DeserializeObject<List<object>>(jsonData);

                    // Đếm số lượng khách hàng
                    ViewBag.CustomerCount = customers?.Count ?? 0;
                }
                else
                {
                    ViewBag.CustomerCount = 0;
                }
            }
            catch
            {
                ViewBag.CustomerCount = 0;
            }

            string apiUrlSP = "https://localhost:7146/SanPhamALL";

            try
            {
                // Gửi yêu cầu đến API
                HttpResponseMessage response = await _httpClient.GetAsync(apiUrlSP);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc dữ liệu JSON từ API
                    string jsonData = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách khách hàng
                    var customers = JsonConvert.DeserializeObject<List<object>>(jsonData);

                    // Đếm số lượng khách hàng
                    ViewBag.SPCount = customers?.Count ?? 0;
                }
                else
                {
                    ViewBag.SPCount = 0;
                }
            }
            catch
            {
                ViewBag.SPCount = 0;
            }


            string apiUrlTongDH = "https://localhost:7268/api/HoaDonBan/getall-item";

            try
            {
                // Gửi yêu cầu đến API
                HttpResponseMessage response = await _httpClient.GetAsync(apiUrlTongDH);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc dữ liệu JSON từ API
                    string jsonData = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách khách hàng
                    var customers = JsonConvert.DeserializeObject<List<object>>(jsonData);

                    // Đếm số lượng khách hàng
                    ViewBag.TOngDHCount = customers?.Count ?? 0;
                }
                else
                {
                    ViewBag.TOngDHCount = 0;
                }
            }
            catch
            {
                ViewBag.TOngDHCount = 0;
            }


            string apiUrlSLDH = "https://localhost:7268/api/SoLuong/getall-item";

            try
            {
                // Gửi yêu cầu đến API
                HttpResponseMessage response = await _httpClient.GetAsync(apiUrlSLDH);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc dữ liệu JSON từ API
                    string jsonData = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách khách hàng
                    var customers = JsonConvert.DeserializeObject<List<object>>(jsonData);

                    // Đếm số lượng khách hàng
                    ViewBag.SoLuongDH = customers?.Count ?? 0;
                }
                else
                {
                    ViewBag.SoLuongDH = 0;
                }
            }
            catch
            {
                ViewBag.SoLuongDH = 0;
            }


            string apiUrlKH = "https://localhost:7268/api/KhachHang/getall-item";
            List<KhachHangAdminModel> categories = new List<KhachHangAdminModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlKH);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categories = JsonConvert.DeserializeObject<List<KhachHangAdminModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.dtKH = categories;


            string apiUrlHDB = "https://localhost:7268/api/HoaDonBan/getall-itemTT";
            List<HoaDonBanTTAdminModel> hdban = new List<HoaDonBanTTAdminModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlHDB);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    hdban = JsonConvert.DeserializeObject<List<HoaDonBanTTAdminModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.hdban = hdban;



            return View();
        }


        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile ImageUpload)
        {
            if (ImageUpload == null || ImageUpload.Length == 0)
                return BadRequest("No file uploaded.");

            var fileName = Path.GetFileName(ImageUpload.FileName);
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "img", fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await ImageUpload.CopyToAsync(stream);
            }

            string sourceFilePath = @"E:\APIRemake\moinhat\WebApplicationtest\WebApplicationtest\WebApplicationADMIN\wwwroot\img\" + fileName;  // Path of the file to copy
            string destinationFilePath = @"E:\APIRemake\moinhat\WebApplicationtest\WebApplicationtest\WebShopTayCam\wwwroot\img\"+ fileName;

            if (System.IO.File.Exists(sourceFilePath))
            {
                System.IO.File.Copy(sourceFilePath, destinationFilePath, overwrite: true);

            }


            ViewBag.fileName = fileName;
            return Json(new { success = true, fileName = fileName }); // Trả về thông tin JSON
        }

        public async Task<IActionResult> IndexQLSP()
        {


            string apiUrlKH = "https://localhost:7268/api/SanPham/getall-itemadmin";
            List<SanPhamAdminModel> categories = new List<SanPhamAdminModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlKH);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categories = JsonConvert.DeserializeObject<List<SanPhamAdminModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.dtSP = categories;

            return View();
        }


        //[HttpGet]
        //public async Task<IActionResult> ViewOrder(int orderId)
        //{
        //    try
        //    {
        //        // Gọi API lấy danh sách sản phẩm trong hóa đơn
        //        var orderResponse = await _httpClient.GetStringAsync($"https://localhost:7268/api/ChiTietHoaDonBan/getall-itembyidmahd?id={orderId}");
        //        var orderDetails = JsonConvert.DeserializeObject<List<ChiTietHDBanModel>>(orderResponse);

        //        // Gọi API lấy thông tin khách hàng
        //        var customerResponse = await _httpClient.GetStringAsync($"https://localhost:7268/api/KhachHang/getall-itembymahd?id={orderId}");
        //        var customers = JsonConvert.DeserializeObject<List<KhachHangAdminModel>>(customerResponse);

        //        var result = new
        //        {
        //            OrderDetails = orderDetails ?? new List<ChiTietHDBanModel>(),  // Nếu null, trả về danh sách trống
        //            Customer = customers?.FirstOrDefault()  // Lấy khách hàng đầu tiên nếu có
        //        };


        //        return Json(result);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new { message = "Lỗi khi lấy dữ liệu!", error = ex.Message });
        //    }
        //}


        [HttpGet]
        public async Task<IActionResult> GetOrderDetails(int orderId)
        {
            try
            {
                var orderResponse = await _httpClient.GetStringAsync($"https://localhost:7268/api/ChiTietHoaDonBan/getall-itembyidmahd?id={orderId}");
                var orderDetails = JsonConvert.DeserializeObject<List<ChiTietHDBanModel>>(orderResponse) ?? new List<ChiTietHDBanModel>();

                return Json(orderDetails);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Lỗi khi lấy chi tiết hóa đơn!", error = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetCustomerInfo(int orderId)
        {
            try
            {
                var customerResponse = await _httpClient.GetStringAsync($"https://localhost:7268/api/KhachHang/getall-itembymahd?id={orderId}");
                var customers = JsonConvert.DeserializeObject<List<KhachHangAdminModel>>(customerResponse);

                var customer = customers?.FirstOrDefault(); // Lấy khách hàng đầu tiên nếu có

                return Json(customer);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Lỗi khi lấy thông tin khách hàng!", error = ex.Message });
            }
        }


        [HttpPost]
        public async Task<JsonResult> XoaSP(string id)
        {


            if (string.IsNullOrEmpty(id))
            {
                return Json(new { success = false, message = "ID sản phẩm không hợp lệ!" });
            }

            // ✅ Gọi hàm LoginAsync trước khi xóa khách hàng
            // Đăng nhập trước để lấy token
            // 🟢 1. Gọi API đăng nhập để lấy token
            JsonResult loginResponse = await DangNhap("ad", "1");

            // Chuyển JsonResult thành JSON string
            string loginJson = JsonConvert.SerializeObject(loginResponse.Value);

            // Deserialize thành object để lấy token
            dynamic loginResult = JsonConvert.DeserializeObject<dynamic>(loginJson);

            if (loginResult == null || loginResult.success == false)
            {
                return Json(new { success = false, message = "Không thể đăng nhập để lấy token!" });
            }

            string token = loginResult.token;


            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = new System.Uri("https://localhost:7268/api/SanPham/delete-item"),
                    Content = new StringContent($"\"{id}\"", Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON
                };

                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                HttpResponseMessage response = await _httpClient.SendAsync(request);


                if (response.IsSuccessStatusCode)
                {
                    return Json(new { success = true, message = "Xóa sản phẩm thành công!" });
                }
                else
                {
                    return Json(new { success = false, message = "Xóa sản phẩm thất bại!" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Lỗi: " + ex.Message });
            }
        }




        [HttpPost]
        public async Task<JsonResult> XoaHoaDonBan(string id)
        {


            if (string.IsNullOrEmpty(id))
            {
                return Json(new { success = false, message = "ID hóa đơn bán không hợp lệ!" });
            }

            // ✅ Gọi hàm LoginAsync trước khi xóa khách hàng
            // Đăng nhập trước để lấy token
            // 🟢 1. Gọi API đăng nhập để lấy token
            JsonResult loginResponse = await DangNhap("ad", "1");

            // Chuyển JsonResult thành JSON string
            string loginJson = JsonConvert.SerializeObject(loginResponse.Value);

            // Deserialize thành object để lấy token
            dynamic loginResult = JsonConvert.DeserializeObject<dynamic>(loginJson);

            if (loginResult == null || loginResult.success == false)
            {
                return Json(new { success = false, message = "Không thể đăng nhập để lấy token!" });
            }

            string token = loginResult.token;


            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = new System.Uri("https://localhost:7268/api/HoaDonBan/delete-item"),
                    Content = new StringContent($"\"{id}\"", Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON
                };

                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                HttpResponseMessage response = await _httpClient.SendAsync(request);


                if (response.IsSuccessStatusCode)
                {
                    return Json(new { success = true, message = "Xóa hóa đơn bán thành công!" });
                }
                else
                {
                    return Json(new { success = false, message = "Xóa hóa đơn bán thất bại!" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Lỗi: " + ex.Message });
            }
        }


        [HttpPut("SuaSP")]
        public async Task<JsonResult> SuaSP([FromBody] SanPhamAdminmodelsua model)
        {

            // ✅ Gọi hàm LoginAsync trước khi xóa khách hàng
            // Đăng nhập trước để lấy token
            // 🟢 1. Gọi API đăng nhập để lấy token
            JsonResult loginResponse = await DangNhap("ad", "1");

            // Chuyển JsonResult thành JSON string
            string loginJson = JsonConvert.SerializeObject(loginResponse.Value);

            // Deserialize thành object để lấy token
            dynamic loginResult = JsonConvert.DeserializeObject<dynamic>(loginJson);

            if (loginResult == null || loginResult.success == false)
            {
                return Json(new { success = false, message = "Không thể đăng nhập để lấy token!" });
            }

            string token = loginResult.token;


            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Put,
                    RequestUri = new System.Uri("https://localhost:7268/api/SanPham/update-item"),
                    Content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON

                };

                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                HttpResponseMessage response = await _httpClient.SendAsync(request);


                if (response.IsSuccessStatusCode)
                {
                    return Json(new { success = true, message = "Chỉnh sửa sản phẩm thành công!" });
                }
                else
                {
                    return Json(new { success = false, message = "Chỉnh sửa sản phẩm thất bại!" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Lỗi: " + ex.Message });
            }
        }



        [HttpPut("SuaHDBan")]
        public async Task<JsonResult> SuaHDBan([FromBody] HoaDonBanTTSuaModel model)
        {

            // ✅ Gọi hàm LoginAsync trước khi xóa khách hàng
            // Đăng nhập trước để lấy token
            // 🟢 1. Gọi API đăng nhập để lấy token
            JsonResult loginResponse = await DangNhap("ad", "1");

            // Chuyển JsonResult thành JSON string
            string loginJson = JsonConvert.SerializeObject(loginResponse.Value);

            // Deserialize thành object để lấy token
            dynamic loginResult = JsonConvert.DeserializeObject<dynamic>(loginJson);

            if (loginResult == null || loginResult.success == false)
            {
                return Json(new { success = false, message = "Không thể đăng nhập để lấy token!" });
            }

            string token = loginResult.token;


            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Put,
                    RequestUri = new System.Uri("https://localhost:7268/api/HoaDonBan/update-item"),
                    Content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON

                };

                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                HttpResponseMessage response = await _httpClient.SendAsync(request);


                if (response.IsSuccessStatusCode)
                {
                    return Json(new { success = true, message = "Chỉnh sửa hóa đơn thành công!" });
                }
                else
                {
                    return Json(new { success = false, message = "Chỉnh sửa hóa đơn thất bại!" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Lỗi: " + ex.Message });
            }
        }





        [HttpPut("SuaHDNhap")]
        public async Task<JsonResult> SuaHDNhap([FromBody] HoaDonNhapADMINModel model)
        {

            // ✅ Gọi hàm LoginAsync trước khi xóa khách hàng
            // Đăng nhập trước để lấy token
            // 🟢 1. Gọi API đăng nhập để lấy token
            JsonResult loginResponse = await DangNhap("ad", "1");

            // Chuyển JsonResult thành JSON string
            string loginJson = JsonConvert.SerializeObject(loginResponse.Value);

            // Deserialize thành object để lấy token
            dynamic loginResult = JsonConvert.DeserializeObject<dynamic>(loginJson);

            if (loginResult == null || loginResult.success == false)
            {
                return Json(new { success = false, message = "Không thể đăng nhập để lấy token!" });
            }

            string token = loginResult.token;


            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Put,
                    RequestUri = new System.Uri("https://localhost:7268/api/ChiTietHoaDonNhapADMIN/update-item"),
                    Content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON

                };

                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                HttpResponseMessage response = await _httpClient.SendAsync(request);


                if (response.IsSuccessStatusCode)
                {
                    return Json(new { success = true, message = "Chỉnh sửa hóa đơn nhập thành công!" });
                }
                else
                {
                    return Json(new { success = false, message = "Chỉnh sửa hóa đơn nhập thất bại!" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Lỗi: " + ex.Message });
            }
        }


        public IActionResult IndexThemSanPham()
        {
            return View();
        }

        public async Task<IActionResult> IndexQLHoaDonBan()
        {

            string apiUrlKH = "https://localhost:7268/api/HoaDonBan/getall-itemTT";
            List<HoaDonBanADMINModel> categories = new List<HoaDonBanADMINModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlKH);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categories = JsonConvert.DeserializeObject<List<HoaDonBanADMINModel>>(jsonString);


                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.dtHD = categories;

            return View();
        }

        public IActionResult IndexThemDonHangBan()
        {
            return View();
        }

        public async Task<IActionResult> IndexQLBaoCao()
        {
            string apiUrlKH = "https://localhost:7268/api/ChiTietHoaDonNhapADMIN/getall-itemdt";
            List<ThongKeDoanhThu> categories = new List<ThongKeDoanhThu>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlKH);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categories = JsonConvert.DeserializeObject<List<ThongKeDoanhThu>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.TongSanPham = categories[0].TongSanPham;
            ViewBag.TongDH = categories[0].TongDH;
            ViewBag.TongThuNhap = categories[0].TongThuNhap;
            ViewBag.TongNhapHang = categories[0].TongNhapHang;
            ViewBag.TongLai = categories[0].TongLai;
            ViewBag.TongHetHang = categories[0].TongHetHang;
            ViewBag.TongDHHuy = categories[0].TongDHHuy;


            string apiSP= "https://localhost:7268/api/SanPham/getall-itemadmin";
            List<SanPhamAdminModel> categoriesSP = new List<SanPhamAdminModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiSP);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categoriesSP = JsonConvert.DeserializeObject<List<SanPhamAdminModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.dtSP = categoriesSP;


            string apiSPHet = "https://localhost:7268/api/SanPham/getall-itemadminhethang";
            List<SanPhamAdminModel> categoriesSPHet = new List<SanPhamAdminModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiSPHet);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categoriesSPHet = JsonConvert.DeserializeObject<List<SanPhamAdminModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.dtSPHet = categoriesSPHet;

            return View();
        }


        // Thay đổi trạng thái bình luận
        public async Task<IActionResult> ThayDoiTrangThai(int id)
        {
            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = new System.Uri("https://localhost:7268/api/BinhLuan/delete-item"),
                    Content = new StringContent($"\"{id}\"", Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON
                };


                HttpResponseMessage response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    // Thêm thông báo thành công
                    TempData["SuccessMessage"] = "Đã thay đổi trạng thái bình luận thành công!";
                }
                else
                {
                    // Thêm thông báo lỗi
                    TempData["ErrorMessage"] = "Có lỗi xảy ra khi thay đổi trạng thái!";
                }
            }
            catch (System.Exception ex)
            {
                // Thêm thông báo lỗi
                TempData["ErrorMessage"] = $"Lỗi: {ex.Message}";
            }

            return RedirectToAction(nameof(IndexQLBinhLuan));

        }


        // Thêm chi tiết bình luận
        [HttpPost]
        public async Task<IActionResult> ThemChiTietBinhLuan(int idBinhLuan, string noiDung, int doiTuongBinhLuan, string tenKhachHang)
        {
            var chiTiet = new ChiTietBinhLuanModel
            {
                ID_BinhLuan = idBinhLuan,
                NoiDung = noiDung,
                DoiTuongBinhLuan = doiTuongBinhLuan,
                NgayBinhLuan = DateTime.Now,
                TenKhachHang = tenKhachHang
            };

            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new System.Uri("https://localhost:7268/api/ChiTietBinhLuan/create-item"),
                    Content = new StringContent(JsonConvert.SerializeObject(chiTiet), Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON

                };

                HttpResponseMessage response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    TempData["SuccessMessage"] = "Đã thêm bình luận thành công!";

                    return RedirectToAction("Details", new { id = idBinhLuan });
                }
                else
                {
                    TempData["ErrorMessage"] = "thêm bình luận thất bại!";
                    return RedirectToAction("Details", new { id = idBinhLuan });
                }
            }
            catch (System.Exception ex)
            {
                TempData["ErrorMessage"] = $"Lỗi: {ex.Message}";
            }
            return RedirectToAction("Details", new { id = idBinhLuan });
        }


        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var user = HttpContext.Session.GetString("UserSesion");
            ViewBag.user = user;

            string apiSP = "https://localhost:7268/api/BinhLuan/getall-item";
            List<BinhLuanModel> categoriesBL = new List<BinhLuanModel>();
            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiSP);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categoriesBL = JsonConvert.DeserializeObject<List<BinhLuanModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }



            string apichitietbl = "https://localhost:7268/api/ChiTietBinhLuan/getall-item";
            List<ChiTietBinhLuanModel> categoriesCTBL = new List<ChiTietBinhLuanModel>();
            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apichitietbl);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categoriesCTBL = JsonConvert.DeserializeObject<List<ChiTietBinhLuanModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }


            // Gộp 2 danh sách lại
            var result = categoriesBL
                 .Where(bl => bl.MaBinhLuan == id) // Điều kiện lọc theo id
                .Select(bl => new BinhLuan
            {
                MaBinhLuan = bl.MaBinhLuan,
                MaKhachHang = bl.MaKhachHang,
                MaSanPham = bl.MaSanPham,
                NoiDung = bl.NoiDung,
                TenKhachHang = bl.TenKhachHang,
                TrangThai = bl.TrangThai,
                ChiTietBinhLuans = categoriesCTBL
                    .Where(ct => ct.ID_BinhLuan == bl.MaBinhLuan)
                    .Select(ct => new ChiTietBinhLuan
                    {
                        ID = ct.ID,
                        ID_BinhLuan = ct.ID_BinhLuan,
                        NoiDung = ct.NoiDung,
                        DoiTuongBinhLuan = ct.DoiTuongBinhLuan,
                        NgayBinhLuan = ct.NgayBinhLuan,
                        TenKhachHang = ct.TenKhachHang
                    })
                    .ToList()
            }).ToList();



            return View(result[0]);
        }

        public async Task<IActionResult> IndexQLBinhLuan()
        {
          
            string apiSP = "https://localhost:7268/api/BinhLuan/getalltensp-item";
            List<BinhLuanTenSPModel> categoriesBL = new List<BinhLuanTenSPModel>();
            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiSP);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categoriesBL = JsonConvert.DeserializeObject<List<BinhLuanTenSPModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }



            string apichitietbl = "https://localhost:7268/api/ChiTietBinhLuan/getall-item";
            List<ChiTietBinhLuanModel> categoriesCTBL = new List<ChiTietBinhLuanModel>();
            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apichitietbl);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categoriesCTBL = JsonConvert.DeserializeObject<List<ChiTietBinhLuanModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }


            // Gộp 2 danh sách lại
            var result = categoriesBL.Select(bl => new BinhLuan
            {
                MaBinhLuan = bl.MaBinhLuan,
                MaKhachHang = bl.MaKhachHang,
                MaSanPham = bl.MaSanPham,
                NoiDung = bl.NoiDung,
                TenKhachHang = bl.TenKhachHang,
                TrangThai = bl.TrangThai,
                TenSanPham = bl.TenSanPham,
                TenTK = bl.TenTK,
                ChiTietBinhLuans = categoriesCTBL
                    .Where(ct => ct.ID_BinhLuan == bl.MaBinhLuan)
                    .Select(ct => new ChiTietBinhLuan
                    {
                        ID = ct.ID,
                        ID_BinhLuan = ct.ID_BinhLuan,
                        NoiDung = ct.NoiDung,
                        DoiTuongBinhLuan = ct.DoiTuongBinhLuan,
                        NgayBinhLuan = ct.NgayBinhLuan,
                        TenKhachHang = ct.TenKhachHang
                    })
                    .ToList()
            }).ToList();


            return View(result);


        }



        [HttpPost]
    public async Task<JsonResult> DangNhap(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return Json(new { success = false, message = "Tài khoản hoặc mật khẩu không hợp lệ!" });
            }

            try
            {
                // Tạo request POST với dữ liệu đăng nhập
                var loginData = new { username, password };
                var content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(loginData), Encoding.UTF8, "application/json");

                HttpResponseMessage response = await _httpClient.PostAsync("https://localhost:7268/api/Users/login", content);

                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    dynamic jsonResponse = Newtonsoft.Json.JsonConvert.DeserializeObject(result);

                    string token = jsonResponse.token;

                    HttpContext.Session.SetString("UserSesion", username);

                    return Json(new { success = true, token = token });


                }
                else
                {
                    return Json(new { success = false, message = "Đăng nhập thất bại!" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Lỗi: " + ex.Message });
            }
        }
    

    [HttpPost]
        public async Task<JsonResult> XoaKH(string id)
        {


            if (string.IsNullOrEmpty(id))
            {
                return Json(new { success = false, message = "ID khách hàng không hợp lệ!" });
            }

            // ✅ Gọi hàm LoginAsync trước khi xóa khách hàng
            // Đăng nhập trước để lấy token
            // 🟢 1. Gọi API đăng nhập để lấy token
            JsonResult loginResponse = await DangNhap("ad", "1");

            // Chuyển JsonResult thành JSON string
            string loginJson = JsonConvert.SerializeObject(loginResponse.Value);

            // Deserialize thành object để lấy token
            dynamic loginResult = JsonConvert.DeserializeObject<dynamic>(loginJson);

            if (loginResult == null || loginResult.success == false)
            {
                return Json(new { success = false, message = "Không thể đăng nhập để lấy token!" });
            }

            string token = loginResult.token;


            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = new System.Uri("https://localhost:7268/api/KhachHang/delete-item"),
                    Content = new StringContent($"\"{id}\"", Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON
                };

                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                HttpResponseMessage response = await _httpClient.SendAsync(request);



                if (response.IsSuccessStatusCode)
                {
                    return Json(new { success = true, message = "Xóa khách hàng thành công!" });
                }
                else
                {
                    return Json(new { success = false, message = "Xóa khách hàng thất bại!" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Lỗi: " + ex.Message });
            }
        }



        public async Task<IActionResult> IndexQLKH()
        {
            string apiUrlKH = "https://localhost:7268/api/KhachHang/getall-item";
            List<KhachHangAdminModel> categories = new List<KhachHangAdminModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlKH);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categories = JsonConvert.DeserializeObject<List<KhachHangAdminModel>>(jsonString);
                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.dtKH = categories;


            return View();

        }


        public async Task<IActionResult> IndexQLHoaDonNhap()
        {

            string apiUrlKH = "https://localhost:7268/api/ChiTietHoaDonNhapADMIN/getall-item";
            List<HoaDonNhapModel> categories = new List<HoaDonNhapModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlKH);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    categories = JsonConvert.DeserializeObject<List<HoaDonNhapModel>>(jsonString);


                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.dtHD = categories;

            return View();
        }



        [HttpPost]
        public async Task<JsonResult> XoaHoaDonNhap(string id)
        {

            if (string.IsNullOrEmpty(id))
            {
                return Json(new { success = false, message = "ID Hóa đơn nhập không hợp lệ!" });
            }

            // ✅ Gọi hàm LoginAsync trước khi xóa khách hàng
            // Đăng nhập trước để lấy token
            // 🟢 1. Gọi API đăng nhập để lấy token
            JsonResult loginResponse = await DangNhap("ad", "1");

            // Chuyển JsonResult thành JSON string
            string loginJson = JsonConvert.SerializeObject(loginResponse.Value);

            // Deserialize thành object để lấy token
            dynamic loginResult = JsonConvert.DeserializeObject<dynamic>(loginJson);

            if (loginResult == null || loginResult.success == false)
            {
                return Json(new { success = false, message = "Không thể đăng nhập để lấy token!" });
            }

            string token = loginResult.token;


            try
            {
                // Gửi request DELETE
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = new System.Uri("https://localhost:7268/api/ChiTietHoaDonNhapADMIN/delete-item"),
                    Content = new StringContent($"\"{id}\"", Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON
                };

                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                HttpResponseMessage response = await _httpClient.SendAsync(request);



                if (response.IsSuccessStatusCode)
                {
                    return Json(new { success = true, message = "Xóa HDN thành công!" });
                }
                else
                {
                    return Json(new { success = false, message = "Xóa HDN thất bại!" });
                }
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Lỗi: " + ex.Message });
            }
        }



        public async Task<IActionResult> IndexThemDonHangNhap()
        {
            string apiUrlKH = "https://localhost:7268/api/NhaCUngCap/getall-item";
            List<NhaCungCapModel> nhacungcap = new List<NhaCungCapModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlKH);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    nhacungcap = JsonConvert.DeserializeObject<List<NhaCungCapModel>>(jsonString);


                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.ncc = new SelectList(nhacungcap, "MaNhaCungCap", "TenNhaCungCap");


            string apiUrlSP = "https://localhost:7268/api/SanPham/getall-item";
            List<SanPhamModel> sanphams = new List<SanPhamModel>();

            try
            {
                // Gửi yêu cầu HTTP GET để lấy dữ liệu từ API
                var response = await _httpClient.GetAsync(apiUrlSP);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc phản hồi JSON thành chuỗi
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Chuyển đổi JSON thành danh sách SanPham
                    sanphams = JsonConvert.DeserializeObject<List<SanPhamModel>>(jsonString);


                }
                else
                {
                    // Xử lý trường hợp lỗi khi gọi API
                    ViewBag.Error = "Không thể lấy dữ liệu từ API.";
                }
            }
            catch (HttpRequestException ex)
            {
                // Xử lý trường hợp có lỗi trong quá trình gọi API
                ViewBag.Error = "Lỗi trong quá trình gọi API: " + ex.Message;
            }

            ViewBag.sp = new SelectList(sanphams, "MaSanPham", "TenSanPham");


            var viewModel = new HoaDonNhapCreateViewModel
            {
                NgayNhap = DateTime.Today,
                TinhTrang = "Đang xử lý", // Default status
                ChiTietHoaDonNhaps = new List<ChiTietHoaDonNhapViewModel>() // Initialize empty list
            };

            return View(viewModel);

  
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<JsonResult> IndexThemDonHangNhap(HoaDonNhapCreateViewModel model)
        {


            if (ModelState.IsValid)
            {

                JsonResult loginResponse = await DangNhap("ad", "1");

                // Chuyển JsonResult thành JSON string
                string loginJson = JsonConvert.SerializeObject(loginResponse.Value);

                // Deserialize thành object để lấy token
                dynamic loginResult = JsonConvert.DeserializeObject<dynamic>(loginJson);

                if (loginResult == null || loginResult.success == false)
                {
                    return Json(new { success = false, message = "Không thể đăng nhập để lấy token!" });
                }

                string token = loginResult.token;



                // Thực hiện kiểm tra đăng nhập ở đây
                string MaHDN = model.MaHoaDonNhap;
    
                List <ChiTietHoaDonNhapViewModel> cts = model.ChiTietHoaDonNhaps;
                string NCC = model.MaNhaCungCap;

                HoaDonNhapADMINCTmodel modelapi = new HoaDonNhapADMINCTmodel();

                modelapi.MaHoaDonNhap = Convert.ToInt32(model.MaHoaDonNhap);
              
                modelapi.TrangThai = model.TinhTrang;
                modelapi.MaNhaCungCap =Convert.ToInt32(model.MaNhaCungCap);
                modelapi.ChiTietHDNhaps = JsonConvert.SerializeObject(model.ChiTietHoaDonNhaps);


                modelapi.NgayNhap = model.NgayNhap;
                try
                {
                    // Gửi request DELETE
                    var request = new HttpRequestMessage
                    {
                        Method = HttpMethod.Post,
                        RequestUri = new System.Uri("https://localhost:7268/api/ChiTietHoaDonNhapADMIN/createCT-item"),
                        Content = new StringContent(JsonConvert.SerializeObject(modelapi), Encoding.UTF8, "application/json") // Truyền ID dưới dạng chuỗi JSON

                    };

                    request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                    HttpResponseMessage response = await _httpClient.SendAsync(request);


                    if (response.IsSuccessStatusCode)
                    {
                        ViewBag.SuccessMessage = "Thêm thành công";
                        return Json(new { success = true, message = "Thêm thành công" });
                    }
                    else
                    {
                        return Json(new { success = false, message = "Thêm thất bại" });
                    }
                }
                catch (System.Exception ex)
                {
                    return Json(new { success = false, message = "Thêm thất bai" });
                }

            }
            return Json(new { success = false, message = "Thêm thất bại" });
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}