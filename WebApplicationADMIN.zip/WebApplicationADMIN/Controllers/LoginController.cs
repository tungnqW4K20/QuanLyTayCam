﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationADMIN.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
