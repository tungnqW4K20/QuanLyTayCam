﻿namespace WebApplicationADMIN.Models
{
    public class HoaDonBanTTSuaModel
    {

        public int MaHoaDonBan { get; set; }
        public DateTime NgayBan { get; set; }
        public string TrangThai { get; set; }
        public int MaKhachHang { get; set; }

    }
}
