﻿namespace WebApplicationADMIN.Models
{
    public class ChiTietBinhLuan
    {
        public int ID { get; set; }
        public int ID_BinhLuan { get; set; }
        public string NoiDung { get; set; }
        public int DoiTuongBinhLuan { get; set; } // 1: Khách hàng, 0: Nhân viên
        public DateTime NgayBinhLuan { get; set; }
        public string TenKhachHang { get; set; }

        public BinhLuan BinhLuan { get; set; }
    }
}
