﻿namespace WebApplicationADMIN.Models
{
    public class HoaDonNhapADMINModel
    {
        public int MaHoaDonNhap { get; set; }
        public DateTime NgayNhap { get; set; }
        public string TrangThai { get; set; }

        public int MaNhaCungCap { get; set; }

        public int MaChiTietHoaDonNhap { get; set; }

        public int MaSanPham { get; set; }
        public int SoLuongNhap { get; set; }

        public decimal GiaNhap { get; set; }
    }
}
