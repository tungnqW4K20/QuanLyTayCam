﻿namespace WebApplicationADMIN.Models
{
    public class HoaDonNhapModel
    {

        public int MaHoaDonNhap { get; set; }
        public DateTime NgayNhap { get; set; }
        public string TrangThai { get; set; }

        public string NhaCungCap { get; set; }

        public int MaChiTietHoaDonNhap { get; set; }

        public string TenSanPham { get; set; }
        public int SoLuongNhap { get; set; }

        public decimal GiaNhap { get; set; }
    }
}
