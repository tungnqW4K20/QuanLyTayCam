﻿namespace WebApplicationADMIN.Models
{
    public class SanPhamAdminModel
    {
       
            public int MaSanPham { get; set; }
            public string TenSanPham { get; set; }

            public int SoLuong { get; set; }
            public Nullable<decimal> Gia { get; set; }
            public string HinhAnh { get; set; }

            public string TinhTrang { get; set; }

            public string DanhMuc { get; set; }


        
    }
}
