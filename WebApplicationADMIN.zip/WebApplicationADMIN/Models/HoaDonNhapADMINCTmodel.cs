﻿namespace WebApplicationADMIN.Models
{
    public class HoaDonNhapADMINCTmodel
    {
        public int MaHoaDonNhap { get; set; }
        public DateTime NgayNhap { get; set; }
        public string TrangThai { get; set; }

        public int MaNhaCungCap { get; set; }

        public string ChiTietHDNhaps { get; set; }


    }
}
