﻿using System.ComponentModel.DataAnnotations;

namespace WebApplicationADMIN.Models
{
    public class HoaDonNhapCreateViewModel
    {
        [Display(Name = "Mã Hóa Đơn Nhập")]
        // You might make this readonly or hidden if it's auto-generated on the server
        public string? MaHoaDonNhap { get; set; } // Nullable if generated server-side

        [Required(ErrorMessage = "Vui lòng chọn ngày nhập.")]
        [DataType(DataType.Date)]
        [Display(Name = "Ngày Nhập")]
        public DateTime NgayNhap { get; set; } = DateTime.Today; // Default to today

        [Required(ErrorMessage = "Vui lòng chọn nhà cung cấp.")]
        [Display(Name = "Nhà Cung Cấp")]
        public string MaNhaCungCap { get; set; } // Store the selected ID

        [Required(ErrorMessage = "Vui lòng chọn tình trạng.")]
        [Display(Name = "Tình Trạng")]
        public string TinhTrang { get; set; } = "Đang xử lý"; // Default status

        // Predefined list of statuses for the dropdown
        // List to hold the detail items added via JavaScript
        public List<ChiTietHoaDonNhapViewModel> ChiTietHoaDonNhaps { get; set; } = new List<ChiTietHoaDonNhapViewModel>();


    }
}
