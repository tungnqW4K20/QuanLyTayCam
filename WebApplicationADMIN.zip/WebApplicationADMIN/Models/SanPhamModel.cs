﻿namespace WebApplicationADMIN.Models
{
    public class SanPhamModel
    {
        public string MaSanPham { get; set; }
        public string TenSanPham { get; set; }
    }
}
