﻿namespace WebApplicationADMIN.Models
{
    public class BinhLuan
    {
        public int MaBinhLuan { get; set; }
        public int MaKhachHang { get; set; }
        public int MaSanPham { get; set; }
        public string NoiDung { get; set; }
        public string TenKhachHang { get; set; }
        public int TrangThai { get; set; } // 1: Ẩn, 0: Hiện
        public string TenSanPham { get; set; }
        public string TenTK { get; set; }
        public List<ChiTietBinhLuan> ChiTietBinhLuans { get; set; }
    }

}
