﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplicationADMIN.Models
{
    public class BinhLuanModel
    {
        public int MaBinhLuan { get; set; }
        public int MaKhachHang { get; set; }
        public int MaSanPham { get; set; }
        public string NoiDung { get; set; }
        public string TenKhachHang { get; set; }
        public int TrangThai { get; set; }

    }
}
