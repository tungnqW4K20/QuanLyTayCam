// Lắng nghe sự kiện khi nhấn nút gửi
document.getElementById('send-button').addEventListener('click', sendMessage);

// Lắng nghe sự kiện khi nhấn phím Enter trong input
document.getElementById('user-input').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

// Hàm gửi tin nhắn
function sendMessage() {
    const userInput = document.getElementById('user-input');
    const message = userInput.value.trim();
    if (message === '') return;

    appendMessage('user', message);
    userInput.value = '';

    // Thêm timeout để mô phỏng thời gian phản hồi của bot
    setTimeout(() => {
        const botResponse = getBotResponse(message);
        appendMessage('bot', botResponse);

        // Sau khi thêm tin nhắn bot, tự động cuộn thanh cuộn xuống dưới cùng
        scrollToBottom();
    }, 500);
}

// Hàm thêm tin nhắn vào chat box
function appendMessage(sender, message) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', sender);

    const contentElement = document.createElement('div');
    contentElement.classList.add('content');
    contentElement.textContent = message;

    messageElement.appendChild(contentElement);
    chatBox.appendChild(messageElement);

    // Kiểm tra chiều cao của chat-box và thêm/xóa lớp scrollable
    checkScrollHeight();
}

// Hàm kiểm tra chiều cao của chat-box và thêm/xóa lớp scrollable
function checkScrollHeight() {
    const chatBox = document.getElementById('chat-box');
    if (chatBox.scrollHeight > 500) {
        chatBox.classList.add('scrollable');
    } else {
        chatBox.classList.remove('scrollable');
    }

    // Hàm cuộn thanh cuộn xuống dưới cùng
    scrollToBottom();
}

// Hàm tự động cuộn thanh cuộn xuống dưới cùng
function scrollToBottom() {
    const chatBox = document.getElementById('chat-box');
    chatBox.scrollTop = chatBox.scrollHeight;
}

// Hàm xử lý tin nhắn của bot
function getBotResponse(message) {
    message = message.toLowerCase();
    if (message.includes('giờ làm việc') || message.includes('giờ giấc') || message.includes('giờ làm') || message.includes('giờ')) {
        return 'Giờ làm việc của chúng tôi là từ 8h sáng đến 5h chiều, từ thứ hai đến thứ sáu.';
    } else if (message.includes('địa chỉ')) {
        return 'Địa chỉ của chúng tôi là số 123 Đường ABC, Thành phố XYZ.';
    } else if (message.includes('mua hàng') || message.includes('thanh toán') || message.includes('cách thức mua')) {
        return 'Bạn có thể mua hàng trực tuyến trên trang web của chúng tôi hoặc ghé thăm cửa hàng để mua trực tiếp. Chúng tôi chấp nhận thanh toán bằng thẻ và tiền mặt.';
    } else if (message.includes('sản phẩm') || message.includes('loại sản phẩm') || message.includes('có gì bán')) {
        return 'Chúng tôi cung cấp nhiều sản phẩm đa dạng, bạn có thể tham khảo trên trang web của chúng tôi hoặc đến cửa hàng để xem trực tiếp.';
    } else if (message.includes('chính sách đổi trả') || message.includes('đổi trả') || message.includes('trả hàng')) {
        return 'Chính sách đổi trả của chúng tôi là trong vòng 30 ngày kể từ khi mua hàng, với điều kiện sản phẩm chưa qua sử dụng và còn nguyên tem mác.';
    } else if (message.includes('hỗ trợ') || message.includes('liên hệ') || message.includes('giúp đỡ')) {
        return 'Bạn có thể liên hệ với chúng tôi qua số điện thoại (+84) 123-456-789 hoặc email support@example.com để được hỗ trợ.';
    } else if (message.includes('giá cả') || message.includes('bao nhiêu tiền') || message.includes('giá sản phẩm')) {
        return 'Giá cả của sản phẩm thường dao động từ A đến B. Bạn có thể xem chi tiết giá cả trên trang web của chúng tôi hoặc liên hệ trực tiếp để biết thêm thông tin chi tiết.';
    } else if (message.includes('khuyến mãi') || message.includes('ưu đãi') || message.includes('giảm giá')) {
        return 'Chúng tôi thường có các chương trình khuyến mãi và ưu đãi đặc biệt cho khách hàng. Bạn có thể xem thông tin chi tiết về các chương trình này trên trang web của chúng tôi.';
    } else if (message.includes('bảo hành') || message.includes('bao lâu') || message.includes('bảo dưỡng')) {
        return 'Chúng tôi cung cấp dịch vụ bảo hành cho sản phẩm trong thời gian nhất định. Bạn có thể tham khảo các điều khoản và điều kiện cụ thể về bảo hành trên trang web của chúng tôi.';
    } else if (message.includes('phí vận chuyển') || message.includes('ship hàng') || message.includes('giao hàng')) {
        return 'Chúng tôi có dịch vụ giao hàng tận nơi. Phí vận chuyển sẽ được tính dựa trên khoảng cách và loại sản phẩm. Bạn có thể xem thông tin chi tiết về phí vận chuyển khi thanh toán đơn hàng.';
    } else if (message.includes('tin tức') || message.includes('thông tin mới nhất') || message.includes('tin hot')) {
        return 'Bạn có thể xem các tin tức và thông tin mới nhất về sản phẩm và dịch vụ của chúng tôi trên trang web hoặc các mạng xã hội của chúng tôi.';
    } else {
        return 'Cảm ơn bạn đã liên hệ! Chúng tôi sẽ trả lời bạn sớm nhất có thể.';
    }
}











