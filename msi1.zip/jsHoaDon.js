window.onload = function() {
            // Tự động cập nhật ngày hiện tại cho hóa đơn
            const today = new Date();
            const date = today.getDate() + '/' + (today.getMonth() + 1) + '/' + today.getFullYear();
            document.getElementById('invoice-date').innerText = date;
        };

        function changeQuantity(button, change) {
            const input = button.parentElement.querySelector('input[type="number"]');
            let quantity = parseInt(input.value) + change;
            if (quantity < 1) quantity = 1; // Đảm bảo số lượng không nhỏ hơn 1
            input.value = quantity;
            updateTotal();
        }

        function updateTotal() {
            const rows = document.querySelectorAll('.invoice-items tbody tr');
            let subtotal = 0;
            rows.forEach(row => {
                const priceCell = row.cells[3].innerText.replace('đ', '').replace('.', '');
                const quantity = row.querySelector('input[type="number"]').value;
                const total = parseInt(priceCell) * parseInt(quantity);
                subtotal += total;
            });
            const tax = subtotal * 0.1; // 10% thuế
            const total = subtotal + tax;

            document.getElementById('subtotal').innerText = subtotal.toLocaleString() + 'đ';
            document.getElementById('tax').innerText = tax.toLocaleString() + 'đ';
            document.getElementById('total').innerText = total.toLocaleString() + 'đ';
        }

        function printInvoice() {
            // Chức năng in hóa đơn
            window.print();
        }