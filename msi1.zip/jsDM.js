function smoothScroll(element, distance, duration) {
    const start = element.scrollLeft;
    const startTime = performance.now();

    function scrollStep(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1); // Tỉ lệ hoàn thành (từ 0 đến 1)
        
        // Hàm easeOutQuad để tạo cảm giác mượt mà
        const easeOutQuad = progress * (2 - progress);
        element.scrollLeft = start + distance * easeOutQuad;

        if (elapsed < duration) {
            window.requestAnimationFrame(scrollStep);
        }
    }

    window.requestAnimationFrame(scrollStep);
}

function slideLeft() {
    const slider = document.getElementById("slider");
    smoothScroll(slider, -220, 100); // Cuộn về bên trái 220px trong 500ms
}

function slideRight() {
    const slider = document.getElementById("slider");
    smoothScroll(slider, 220, 100); // Cuộn về bên phải 220px trong 500ms
}
