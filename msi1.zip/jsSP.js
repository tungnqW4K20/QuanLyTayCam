//lướt lên
document.getElementById("scrollToTopBtn").addEventListener("click", function() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});



// tìm kiếm sản phẩm
function searchProducts() {
        let input, filter, productItems, productName, i, txtValue;
        input = document.getElementById('searchInput');
        filter = input.value.toUpperCase();
        productItems = document.getElementsByClassName('product-item');
		
        for (i = 0; i < productItems.length; i++) {
            productName = productItems[i].getElementsByTagName("h3")[0];
            txtValue = productName.textContent || productName.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                productItems[i].classList.remove('hidden');
            } else {
                productItems[i].classList.add('hidden');
            }
        }
    }
	
	
document.getElementById("addProductForm").addEventListener("submit", function(e) {
    e.preventDefault();
    addProduct();
});

function addProduct() {
    // Lấy thông tin sản phẩm từ form
    const name = document.getElementById("productName").value;
    const description = document.getElementById("productDescription").value;
    const price = document.getElementById("productPrice").value;
    const imageInput = document.getElementById("productImage");
    const imageFile = imageInput.files[0];

    if (!imageFile) {
        alert("Vui lòng chọn một ảnh sản phẩm.");
        return;
    }

    // Tạo FileReader để đọc ảnh
    const reader = new FileReader();

    reader.onload = function(event) {
        const imageUrl = event.target.result;

        // Tạo phần tử sản phẩm mới
        const newProduct = document.createElement("div");
        newProduct.classList.add("product-item");

        newProduct.innerHTML = `
            <img src="${imageUrl}" alt="${name}">
            <h3>${name}</h3>
            <p class="description">${description}</p>
            <p>${price} đ</p>
            <a href="#" class="btn">Mua Ngay</a>
        `;

        // Thêm sản phẩm mới vào danh sách sản phẩm
        document.querySelector(".product-grid").appendChild(newProduct);

        // Reset form
        document.getElementById("addProductForm").reset();
    };

    reader.readAsDataURL(imageFile);
}









