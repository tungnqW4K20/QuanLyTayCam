//lướt lên
document.getElementById("scrollToTopBtn").addEventListener("click", function() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});

// tìm kiếm sản phẩm
function searchProducts() {
        let input, filter, productItems, productName, i, txtValue;
        input = document.getElementById('searchInput');
        filter = input.value.toUpperCase();
        productItems = document.getElementsByClassName('product-item');
		
        for (i = 0; i < productItems.length; i++) {
            productName = productItems[i].getElementsByTagName("h1")[0];
            txtValue = productName.textContent || productName.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                productItems[i].classList.remove('hidden');
            } else {
                productItems[i].classList.add('hidden');
            }
        }
    }
	



	
	

	


	

