// Hàm hiển thị thông báo
        function showNotification(message) {
            const notification = document.getElementById('notification');
            notification.textContent = message;
            notification.classList.add('show');
            
        }
//-----------GIỎ HÀNG---------------
        
function showNotification(message) {
    alert(message);
}

document.getElementById("buyNow").addEventListener("click", function(event) {
    event.preventDefault();

    const product = {
		id:ID_product,
        name: document.querySelector(".product-info h1").innerText.trim(),
        price: parseFloat(document.querySelector(".product-info p").innerText.replace(/\D/g, '')),
        image: document.getElementById("currentImage").src,
        quantity: 1
    };

    let cartItems = JSON.parse(localStorage.getItem('cartItems1')) || [];
    const existingItemIndex = cartItems.findIndex(item => item.name === product.name);

    if (existingItemIndex >= 0) {
        if (confirm("Sản phẩm đã có trong giỏ hàng. Bạn vẫn muốn thêm ?")) {
            cartItems[existingItemIndex].quantity += 1;
            localStorage.setItem('cartItems1', JSON.stringify(cartItems));
            showNotification("Số lượng sản phẩm này trong giỏ hàng đã tăng lên 1.");
        }
    } else {
        cartItems.push(product);
        localStorage.setItem('cartItems1', JSON.stringify(cartItems));
        showNotification("Thêm vào giỏ hàng thành công!");
    }
});

			document.addEventListener('DOMContentLoaded', function() {
    const btnOpen = document.querySelector('.btn-open');
    const btnClose = document.querySelector('.btn-close');
    const chatContainer = document.querySelector('.chat-container');

    // Mở khung chat khi click vào nút "Chat Nhanh Với Chúng Tôi"
    btnOpen.addEventListener('click', function() {
        chatContainer.style.display = 'flex';
    });

    // Đóng khung chat khi click vào nút "Đóng"
    btnClose.addEventListener('click', function() {
        chatContainer.style.display = 'none';
    });
});

	//lướt lên
document.getElementById("scrollToTopBtn").addEventListener("click", function() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});

function toggleVideoForm() {
  var videoForm = document.getElementById('videoForm');
  if (videoForm.style.display === 'none' || videoForm.style.display === '') {
    videoForm.style.display = 'block';
  } else {
    closeVideoForm();
  }
}

function closeVideoForm() {
  var videoForm = document.getElementById('videoForm');
  var video = document.getElementById("uploadedVideo");
  video.pause();
  video.currentTime = 0;
  videoForm.style.display = 'none';
}

function previewVideo(event) {
  var video = document.getElementById("uploadedVideo");
  var file = event.target.files[0];
  if (file) {
    var videoSrc = URL.createObjectURL(file);
    var videoSource = document.getElementById("videoSource");
    videoSource.src = videoSrc;
    video.load();
  }
}

function playPause() {
  var video = document.getElementById("uploadedVideo");
  if (video.paused) {
    video.play();
  } else {
    video.pause();
  }
}

function skipForward() {
  var video = document.getElementById("uploadedVideo");
  video.currentTime += 10; // Tua về phía trước 10 giây
}

function skipBackward() {
  var video = document.getElementById("uploadedVideo");
  video.currentTime -= 10; // Tua về phía sau 10 giây
}

function adjustVolume() {
  var video = document.getElementById("uploadedVideo");
  var volume = document.getElementById("volumeRange").value;
  video.volume = volume;
}

// JavaScript cho kéo thả
dragElement(document.getElementById("videoForm"));

function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  if (elmnt.getElementsByClassName("draggable")[0]) {
    elmnt.getElementsByClassName("draggable")[0].onmousedown = dragMouseDown;
  } else {
    elmnt.onmousedown = dragMouseDown;
  }

  function dragMouseDown(e) {
    e = e || window.event;
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
  }

  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}




var ID_product="";

// ấn vô thì hiện lên chi tiết 
 document.addEventListener("DOMContentLoaded", function() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = parseInt(urlParams.get('id')); // Chuyển đổi thành số nguyên để đảm bảo phù hợp với key trong object
	ID_product = productId;
    const productInfo = {
        1: {
            name: "Sony PlayStation 5 Slim (PS5 Slim)",
            price: "13.300.000 VND",
            description: "Sony PlayStation 5 Slim (PS5 Slim) là phiên bản mới nhất của dòng máy chơi game PlayStation từ Sony. Với thiết kế mỏng nhẹ, hiệu năng mạnh mẽ và khả năng chơi game ở độ phân giải 4K, đây là lựa chọn tuyệt vời cho các game thủ.",
            mota2: "CPU: AMD Ryzen Zen 2",
            mota3: "GPU: AMD RDNA 2",
            mota4: "RAM: 16GB GDDR6",
            mota5: "Storage: 825GB SSD",
            image: "ps52_9_11zon.png",
            anh1: "ps52_9_11zon.png",
            anh2: "ps53_11zon.png",
            anh3: "ps54_10_11zon.png",
            anh4: "ps55_11_11zon.png"
        },
        2: {
            name: "Sony Playstation 5 Spiderman 2",
            price: "15.990.000 VND",
           
            description: "Phiên bản đặc biệt của PS5 với chủ đề Spiderman 2, đi kèm các tính năng độc quyền và hiệu năng cao, hoàn hảo cho các fan của Spiderman.",
            mota2: "CPU: AMD Ryzen Zen 3",
            mota3: "GPU: AMD RDNA 3",
            mota4: "RAM: 16GB GDDR6",
            mota5: "Storage: 825GB SSD",
            image: "ps5spider_1_11zon.png",
            anh1: "ps5spider1_2_11zon.png",
            anh2: "ps5spider3_4_11zon.png",
            anh3: "ps5spider_1_11zon.png",
            anh4: "pssspider.jpg"
        },
        // Thêm các sản phẩm khác vào đây tương tự
		3: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Phiên bản đặc biệt của PS5 với chủ đề Spiderman 2, đi kèm các tính năng độc quyền và hiệu năng cao, hoàn hảo cho các fan của Spiderman.",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
            image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        },
		4: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Màn hình: OLED 6.7 Super Retina XDR",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
            image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        },
		5: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Màn hình: OLED 6.7 Super Retina XDR",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
             image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        },
		6: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Màn hình: OLED 6.7 Super Retina XDR",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
             image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        },
		7: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Màn hình: OLED 6.7 Super Retina XDR",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
             image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        },
		8: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Màn hình: OLED 6.7 Super Retina XDR",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
            image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        },
		9: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Màn hình: OLED 6.7 Super Retina XDR",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
            image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        },
		10: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Màn hình: OLED 6.7 Super Retina XDR",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
             image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        },
		11: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Màn hình: OLED 6.7 Super Retina XDR",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
             image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        },
		12: {
            name: "Iphone 13 Pro Max 512GB",
            price: "34.990.000đ",
            priceTG: "33.990.000đ",
            description: "Màn hình: OLED 6.7 Super Retina XDR",
            mota2: "Hệ điều hành: IOS 15",
            mota3: "Camera sau: 3 camera 15 MP",
            mota4: "Camera trước: 15 MP",
            mota5: "Chip: Apple A15 Bionic",
            image: "logo.png",
            anh1: "logo.png",
            anh2: "logo.png",
            anh3: "logo.png",
            anh4: "logo.png"
        }
		
    };

    if (productInfo[productId]) {
        document.querySelector('.product-info h1').innerText = productInfo[productId].name;
        document.querySelector('.price').innerText = productInfo[productId].price;
        document.querySelector('.description').innerText = productInfo[productId].description;
        document.querySelector('.features li:nth-child(1)').innerHTML = `<strong>CPU:</strong> ${productInfo[productId].mota2}`;
        document.querySelector('.features li:nth-child(2)').innerHTML = `<strong>GPU:</strong> ${productInfo[productId].mota3}`;
        document.querySelector('.features li:nth-child(3)').innerHTML = `<strong>RAM:</strong> ${productInfo[productId].mota4}`;
        document.querySelector('.features li:nth-child(4)').innerHTML = `<strong>Storage:</strong> ${productInfo[productId].mota5}`;

        document.getElementById("currentImage").src = productInfo[productId].image;
        document.getElementById("currentImage").alt = productInfo[productId].name;

        document.querySelector('.thumbnail-images img:nth-child(1)').src = productInfo[productId].anh1;
        document.querySelector('.thumbnail-images img:nth-child(2)').src = productInfo[productId].anh2;
        document.querySelector('.thumbnail-images img:nth-child(3)').src = productInfo[productId].anh3;
        document.querySelector('.thumbnail-images img:nth-child(4)').src = productInfo[productId].anh4;
		
		const thumbnailImages = document.querySelectorAll('.thumbnail-images img');
        thumbnailImages.forEach((thumbnail, index) => {
            thumbnail.src = productInfo[productId][`anh${index + 1}`]; // Sử dụng index để lấy ảnh tương ứng
            thumbnail.alt = `${productInfo[productId].name} ${index + 1}`;
            
            // Thêm event listener cho từng ảnh con
            thumbnail.addEventListener('click', function() {
                document.getElementById("currentImage").src = thumbnail.src;
                document.getElementById("currentImage").alt = thumbnail.alt;
            });
        });
    } else {
        document.querySelector('.product-info').innerText = "Sản phẩm không tồn tại.";
    }
});





//Thêm mới

// Hàm để thêm đánh giá vào danh sách
        function addReview(name, comment, file, rating) {
            const reviewsList = document.getElementById('reviewsList');
            const reviewItem = document.createElement('div');
            reviewItem.classList.add('review-item');
            
            let reviewContent = `<strong>Họ tên:</strong> ${name}<br>
                                 <strong>Bình luận:</strong> ${comment}<br>
                                 <strong>Đánh giá sao:</strong> ${'&#9733;'.repeat(rating)}${'&#9734;'.repeat(5 - rating)}`;

            if (file) {
                const fileURL = URL.createObjectURL(file);
                const fileType = file.type.split('/')[0];
                if (fileType === 'image') {
                    reviewContent += `<img src="${fileURL}" alt="Uploaded file">`;
                } else if (fileType === 'video') {
                    reviewContent += `<video controls><source src="${fileURL}" type="${file.type}"></video>`;
                } else if (fileType === 'audio') {
                    reviewContent += `<audio controls><source src="${fileURL}" type="${file.type}"></audio>`;
                }
            }

            reviewItem.innerHTML = reviewContent;
            reviewsList.appendChild(reviewItem);
        }

        // Xử lý sự kiện khi gửi đánh giá
        document.getElementById('reviewForm').addEventListener('submit', function(event) {
            event.preventDefault();
            
            const name = document.getElementById('name').value.trim();
            const comment = document.getElementById('comment').value.trim();
            const file = document.getElementById('fileUpload').files[0];
            const rating = document.querySelector('.rating span.active')?.dataset.value;

            if (name && comment && rating) {
                addReview(name, comment, file, parseInt(rating));
                alert('Đánh giá đã được gửi thành công!');
                this.reset();
                document.querySelectorAll('.rating span').forEach(span => span.classList.remove('active'));
            } else {
                alert('Vui lòng điền đầy đủ thông tin!');
            }
        });

        // Xử lý sự kiện khi chọn sao đánh giá
        document.getElementById('rating').addEventListener('mouseover', function(event) {
            if (event.target.dataset.value) {
                const value = parseInt(event.target.dataset.value);
                document.querySelectorAll('.rating span').forEach(span => {
                    span.classList.toggle('active', parseInt(span.dataset.value) <= value);
                });
            }
        });

        document.getElementById('rating').addEventListener('mouseout', function() {
            const activeRating = document.querySelector('.rating .active');
            const value = activeRating ? parseInt(activeRating.dataset.value) : 0;
            document.querySelectorAll('.rating span').forEach(span => {
                span.classList.toggle('active', parseInt(span.dataset.value) <= value);
            });
        });

        document.getElementById('rating').addEventListener('click', function(event) {
            if (event.target.dataset.value) {
                const value = parseInt(event.target.dataset.value);
                document.querySelectorAll('.rating span').forEach(span => {
                    span.classList.remove('active');
                });
                event.target.classList.add('active');
                event.target.previousSibling.classList.add('active');
            }
        });




document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menuToggle');
    const sideMenu = document.getElementById('sideMenu');
    const closeMenu = document.getElementById('closeMenu');

    menuToggle.addEventListener('click', function() {
        if (sideMenu.style.left === '0px') {
            sideMenu.style.left = '-250px';
            menuToggle.innerHTML = '<i class="fas fa-chevron-right"></i>';
        } else {
            sideMenu.style.left = '0px';
            menuToggle.innerHTML = '<i class="fas fa-chevron-left"></i>';
        }
    });

    closeMenu.addEventListener('click', function() {
        sideMenu.style.left = '-250px';
        menuToggle.innerHTML = '<i class="fas fa-chevron-right"></i>';
    });
});
